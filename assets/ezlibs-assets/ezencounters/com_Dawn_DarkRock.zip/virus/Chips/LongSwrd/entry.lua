local DAMAGE = 80
local SLASH_TEXTURE = Engine.load_texture(_modpath .. "Effects/spell_sword_slashes.png")
local BLADE_TEXTURE = Engine.load_texture(_modpath .. "Effects/spell_sword_blades.png")
local AUDIO = Engine.load_audio(_modpath .. "Sounds/SwordSlash.ogg")

local chip = {}

chip.card_create_action = function(user)
	local action = Battle.CardAction.new(user, "PLAYER_SWORD")
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(user:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(user:get_animation())
			hilt_anim:set_state("HILT")

			local blade = hilt:add_attachment("ENDPOINT")
			local blade_sprite = blade:sprite()
			blade_sprite:set_texture(BLADE_TEXTURE)
			blade_sprite:set_layer(-1)

			local blade_anim = blade:get_animation()
			blade_anim:load(_modpath .. "Effects/spell_sword_blades.animation")
			blade_anim:set_state("DEFAULT")
		end)

		local field = user:get_field()
		self:add_anim_action(3, function()
			local sword = create_slash(user)
			local tile = user:get_tile(user:get_facing(), 1)
			local fx = Battle.Artifact.new()
			fx:set_facing(sword:get_facing())
			local anim = fx:get_animation()
			fx:set_texture(SLASH_TEXTURE, true)
			anim:load(_modpath .. "Effects/spell_sword_slashes.animation")
			anim:set_state("LONG")
			anim:on_complete(function()
				fx:erase()
				if not sword:is_deleted() then sword:delete() end
			end)
			field:spawn(sword, tile)
			field:spawn(fx, tile)
		end)
	end
	return action
end

function create_slash(user)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			DAMAGE,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)
	local attack_once = true
	local field = user:get_field()
	spell.update_func = function(self, dt)
		local tile = spell:get_current_tile()
		local tile_next = tile:get_tile(spell:get_facing(), 1)
		if tile_next and not tile_next:is_edge() then
			tile_next:highlight(Highlight.Flash)
		end
		if attack_once then
			if tile_next and not tile_next:is_edge() then
				local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
				hitbox_r:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_r, tile_next)
			end
			attack_once = false
		end
		tile:attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

return chip
