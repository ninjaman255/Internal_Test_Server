local shared_package_init = include("./character.lua")

--custom properties:
-- max_boomerangs: amount of boomerangs Quickman will throw before idling again.
function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.enemy.Quickman"}
            local aliases = {["QuickMan"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Quickman",
        hp = 600,
        damage = 40,
        palette = _folderpath .. "base.png",
        height = 44,
        element = Element.None,
        max_boomerangs = 1
    }
    if character:get_rank() == Rank.V2 then
        character_info.hp = 900
        character_info.damage = 80
        character_info.sword_damage = 120
        character_infomax_boomerangs = 2
        character_infoname = "QuickmanV"
    end
    if character:get_rank() == Rank.V3 then
        character_info.hp = 1200
        character_info.damage = 120
        character_info.sword_damage = 180
        character_info.max_boomerangs = 2
        character_info.name = "QuickmanV"
    end
    if character:get_rank() == Rank.SP then
        character_info.hp = 1600
        character_info.damage = 200
        character_info.sword_damage = 280
        character_info.palette = _folderpath .. "SP.png"
        character_info.max_boomerangs = 3
        character_info.name = "Quickman"
    end
    if character:get_rank() == Rank.NM then
        character_info.hp = 2500
        character_info.damage = 280
        character_info.sword_damage = 400
        character_info.palette = _folderpath .. "DS.png"
        character_info.max_boomerangs = 3
        character_info.name = "Quickman"
    end
    shared_package_init(character, character_info)
end
