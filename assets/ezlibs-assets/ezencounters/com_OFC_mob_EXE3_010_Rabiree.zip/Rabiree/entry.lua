local shared_package_init = include("../Rabiree/character.lua")

function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.OFC.char.EXE3-010-Rabiree"}
            local aliases = {["Rabiree"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Rabiree",
        name_on_spawn = true,
        health = 40,
        damage = 15,
        element = Element.Elec,
        damage_rabiring = 15,
        frames_between_actions = 34,
        fast_hop_frames = 4,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "HiRabiree"
        character_info.health = 100
        character_info.damage = 60
        character_info.damage_rabiring = 60
        character_info.frames_between_actions = 26
        character_info.fast_hop_frames = 4
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "M-Rabiree"
        character_info.health = 160
        character_info.damage = 90
        character_info.damage_rabiring = 90
        character_info.frames_between_actions = 18
        character_info.fast_hop_frames = 4
    elseif character:get_rank() == Rank.SP then
        character_info.name_on_spawn = false
        character_info.health = 220
        character_info.damage = 150
        character_info.damage_rabiring = 150
        character_info.frames_between_actions = 14
        character_info.fast_hop_frames = 4
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end