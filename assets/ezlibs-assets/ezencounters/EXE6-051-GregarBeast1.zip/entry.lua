local package_id = "com.OFC.mob.EXE6-051-GregarBeast1"
local character_id = "com.OFC.char.EXE6-051-GregarBeast1"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."GregarBeast")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Gregar Beast (EXE6)")
    package:set_description("Test fight with\nGregar Beast\nfrom Rockman EXE6")
    package:set_speed(1)
    package:set_attack(30)
    package:set_health(900)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."08b-underground.png"
    local animPath = _modpath.."08-urainternet.animation"
    mob:set_background(texPath, animPath, 0, 0)
    mob:stream_music(_modpath.."exe6-boss.ogg", 6817, 58254)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
end