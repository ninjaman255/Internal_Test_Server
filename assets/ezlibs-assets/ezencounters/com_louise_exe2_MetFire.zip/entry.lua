--ID of the package
local package_id = "com.louise.exe2.MetFire"
-- prefix of the character id
local character_id = "com.louise.enemy."

function package_requires_scripts()
  --Define characters here.
  Engine.define_character(character_id .. "MetFire", _modpath .. "MetFire")
  Engine.define_character(character_id .. "FulFire", _modpath .. "FulFire")
  Engine.define_character(character_id .. "DthFire", _modpath .. "DthFire")
end

--package init.
function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("MetFire")
  package:set_description("More meteors!")
  package:set_speed(1)
  package:set_attack(40)
  package:set_health(150)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

-- setup the test package
function package_build(mob)
  mob:create_spawner(character_id .. "MetFire", Rank.V1):spawn_at(5, 2)
end
