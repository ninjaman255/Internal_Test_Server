local shared_package_init = include("./character.lua")
function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.enemy.Swordy"}
            local aliases = {["Swordy"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Swordy",
        hp = 90,
        damage = 30,
        height = 44,
        move_speed = 52,
        element = Element.None,
        palette = _folderpath .. "V1.png"
    }

    if character:get_rank() == Rank.V2 then
        character_info.move_speed = 42
        character_info.damage = 60
        character_info.element = Element.Fire
        character_info.palette = _folderpath .. "V2.png"
        character_info.hp = 140
    end

    if character:get_rank() == Rank.V3 then
        character_info.move_speed = 32
        character_info.damage = 100
        character_info.element = Element.Aqua
        character_info.palette = _folderpath .. "V3.png"
        character_info.hp = 220
    end

    if character:get_rank() == Rank.SP then
        character_info.damage = 200
        character_info.move_speed = 16
        character_info.element = Element.None
        character_info.palette = _folderpath .. "SP.png"
        character_info.hp = 320
    end
    if character:get_rank() == Rank.NM then
        character_info.damage = 280
        character_info.element = Element.None
        character_info.palette = _folderpath .. "NM.png"
        character_info.hp = 500
        character_info.move_speed = 10
    end

    shared_package_init(character, character_info)
end
