local package_id = "com.louise.HardHead"
local character_id = "com.louise.enemy."

function package_requires_scripts()
  Engine.define_character(character_id .. "HardHead", _modpath .. "HardHead")
  Engine.define_character(character_id .. "ColdHead", _modpath .. "ColdHead")
  Engine.define_character(character_id .. "HotHead", _modpath .. "HotHead")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("HardHead")
  package:set_description("Bn3 HardHeads")
  package:set_speed(1)
  package:set_attack(60)
  package:set_health(80)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "HardHead", Rank.V1)
  spawner:spawn_at(4, 1)
  local spawner = mob:create_spawner(character_id .. "ColdHead", Rank.V1)
  spawner:spawn_at(4, 3)
  local spawner = mob:create_spawner(character_id .. "HotHead", Rank.V1)
  spawner:spawn_at(6, 1)
  local spawner = mob:create_spawner(character_id .. "HardHead", Rank.SP)
  spawner:spawn_at(6, 3)
  -- local spawner = mob:create_spawner(character_id .. "HardHead", Rank.SP)
  -- spawner:spawn_at(5, 1)
  -- local spawner = mob:create_spawner(character_id .. "HardHead", Rank.SP)
  -- spawner:spawn_at(5, 3)
  -- local spawner = mob:create_spawner(character_id .. "HardHead", Rank.NM)
  -- spawner:spawn_at(6, 2)
end
