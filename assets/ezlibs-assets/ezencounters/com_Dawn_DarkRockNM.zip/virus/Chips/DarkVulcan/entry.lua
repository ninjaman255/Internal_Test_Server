local vulcan = include("vulcan/vulcan.lua")

vulcan.name = "DrkVulcn"
vulcan.codes = {"H"}
vulcan.damage = 20
vulcan.time_freeze = false
vulcan.can_boost = false
vulcan.description = "DARK CHIP MADE BY DESIRE"
vulcan.shots_animated = 36
vulcan.hits = 24
vulcan.card_class = CardClass.Dark

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = vulcan.name
    props.damage = vulcan.damage
    props.time_freeze = vulcan.time_freeze
    props.element = Element.None
    props.description = vulcan.description
    props.can_boost = vulcan.can_boost
    props.card_class = vulcan.card_class
    props.limit = 1

    package:declare_package_id("com.Dawn.Dark.Vulcan")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(vulcan.codes)
end

card_create_action = vulcan.card_create_action