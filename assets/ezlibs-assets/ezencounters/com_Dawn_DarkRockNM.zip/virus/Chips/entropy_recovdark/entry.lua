nonce = function() end

local DarkRecov = {name="DarkRecov"}
local health_bug = include("HPBug/entry.lua")
local DAMAGE = 1000
local TEXTURE = Engine.load_texture(_folderpath.."spell_heal.png")
local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("entropy.recovdark")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'*'})

    local props = package:get_card_props()
    props.shortname = "DrkRecov"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    props.description = "BECOME ALMOST INVINCIBLE"
	props.card_class = CardClass.Dark
    props.long_description = "A Dark Chip. Heal 1000 HP, but become HP bugged."
	props.limit = 1
	props.can_boost = false
end

DarkRecov.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_HEAL")

    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")		
		local recov = create_recov("DEFAULT", user)
		actor:get_field():spawn(recov, actor:get_current_tile())
		actor:set_health(actor:get_health() + DAMAGE)
        health_bug.inflict_health_bug(user) 
        local fx = Battle.Artifact.new()
        print ("does this work...?")
	end
    return action
end

function create_recov(animation_state, user)
    local spell = Battle.Spell.new(Team.Other)
    spell:set_texture(TEXTURE, true)
	spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            0,
			Hit.None,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	spell:sprite():set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_folderpath.."spell_heal.animation")
    anim:set_state(animation_state)
	spell:get_animation():on_complete(
		function()
			spell:erase()
		end
	)

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(AUDIO, AudioPriority.High)

    return spell
end

return DarkRecov