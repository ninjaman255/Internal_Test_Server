local debug = false

local attachment_texture = Engine.load_texture(_folderpath .. "attachment.png")
local attachment_animation_path = _folderpath .. "attachment.animation"
local explosion_texture = Engine.load_texture(_folderpath .. "explosion.png")
local explosion_sfx = Engine.load_audio(_folderpath .. "explosion.ogg")
local explosion_animation_path = _folderpath .. "explosion.animation"
local throw_sfx = Engine.load_audio(_folderpath .. "toss_item.ogg")

function debug_print(text)
    if debug then
        print("[MegEnBom] " .. text)
    end
end

local bomb = {
    name="MegEnBom",
    damage=60,
    element=Element.None,
    description = "Throws a bomb 3sq ahead",
    codes = {"*"}
}

bomb.card_create_action = function(user)
    local action = Battle.CardAction.new(user, "PLAYER_THROW")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.064},{2,0.064},{3,0.064},{4,0.064},{5,0.064}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    local hit_props = HitProps.new(
        bomb.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash, 
        bomb.element,
        user:get_context(),
        Drag.None
    )

    action.execute_func = function(self, user)
        --local props = self:copy_metadata()
        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(attachment_texture)
        attachment_sprite:set_layer(-2)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(attachment_animation_path)
        attachment_animation:set_state("DEFAULT")

        user:toggle_counter(true)
        self:add_anim_action(3,function()
            attachment_sprite:hide()
            --self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local facing = user:get_facing()
            local target_tile = user:get_tile(facing,tiles_ahead)
            if not target_tile then
                return
            end
            action.on_landing = function ()
                if target_tile:is_walkable() then
                    hit_explosion(user,target_tile,hit_props,explosion_texture,explosion_animation_path,explosion_sfx)
                end
            end
            toss_spell(user,toss_height,attachment_texture,attachment_animation_path,target_tile,frames_in_air,action.on_landing)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self.action_end_func = function ()
            user:toggle_counter(false)
        end

        Engine.play_audio(throw_sfx, AudioPriority.Highest)
    end
    return action
end

function toss_spell(tosser,toss_height,texture,animation_path,target_tile,frames_in_air,arrival_callback)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("DEFAULT")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function hit_explosion(user,target_tile,props,texture,anim_path,explosion_sound)
    local field = user:get_field()
    local spell = Battle.Spell.new(user:get_team())
    local spell_animation = spell:get_animation()
    spell:set_hit_props(props)
    spell_animation:load(anim_path)
    spell_animation:set_state("DEFAULT")
    spell:set_texture(texture)
    spell:sprite():set_layer(-2)
    spell_animation:refresh(spell:sprite())
    spell_animation:set_playback(Playback.Loop)
	spell.hits = 3
    local do_once = true
    spell.has_attacked = false
    spell.update_func = function(self, dt)
        if not spell.has_attacked then
            spell:get_current_tile():attack_entities(self)
            spell_animation:refresh(spell:sprite())
            spell_animation:on_frame(3, function()
                if spell.hits > 1 then
                    spell.hits = spell.hits - 1
                    local hitbox = Battle.Hitbox.new(spell:get_team())
                    if hits == 1 then
                        local props = HitProps.new(
                            HitProps.new(
                                bomb.damage,
                                Hit.Impact | Hit.Flinch | Hit.Flash, 
                                bomb.element,
                                user:get_context(), 
                                Drag.None
                            )
                        )
                        hitbox:set_hit_props(props)
                    else
                        hitbox:set_hit_props(spell:copy_hit_props())
                    end
                    field:spawn(hitbox, spell:get_current_tile())
                    --Engine.play_audio(AUDIO, AudioPriority.High)
                else
                    spell:erase()
                end
            end)
            do_once = false
        end
        self:get_current_tile():attack_entities(self)
    end
    Engine.play_audio(explosion_sound, AudioPriority.Highest)
    spell.collision_func = function(self, other)
    end
    spell.attack_func = function(self, other) 
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, target_tile)
end
return bomb