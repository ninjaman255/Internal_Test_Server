local package_id = "com.louise.Puffy"
local character_id = "com.louise.enemy."

-- To spawn this enemy use
-- com.louise.enemy.Puffy


function package_requires_scripts()
  Engine.define_character(character_id .. "Puffy", _modpath .. "Puffy")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Puffy")
  package:set_description("Bn6 Puffy")
  package:set_speed(1)
  package:set_attack(10)
  package:set_health(80)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "Puffy", Rank.SP)
  spawner:spawn_at(4, 1)
  local spawner = mob:create_spawner(character_id .. "Puffy", Rank.Rare1)
  spawner:spawn_at(5, 2)
  local spawner = mob:create_spawner(character_id .. "Puffy", Rank.Rare2)
  spawner:spawn_at(6, 3)
  -- local spawner = mob:create_spawner(character_id .. "HardHead", Rank.SP)
  -- spawner:spawn_at(5, 1)
  -- local spawner = mob:create_spawner(character_id .. "HardHead", Rank.SP)
  -- spawner:spawn_at(5, 3)
  -- local spawner = mob:create_spawner(character_id .. "HardHead", Rank.NM)
  -- spawner:spawn_at(6, 2)
end
