local shared_package_init = include("./character.lua")
function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.enemy.Elemperor"}
            local aliases = {["Elemperor"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Elemperor",
        hp = 100,
        damage = 30,
        palette = _folderpath .. "V1.png",
        height = 44,
        element = Element.None,
        frames_before_attack = 88
    }
    if character:get_rank() == Rank.V2 then
        character_info.hp = 140
        character_info.damage = 60
        character_info.palette = _folderpath .. "V2.png"
    end
    if character:get_rank() == Rank.Rare1 then
        character_info.hp = 220
        character_info.damage = 90
        character_info.palette = _folderpath .. "Rare1.png"
    end
    if character:get_rank() == Rank.V3 then
        character_info.hp = 180
        character_info.damage = 120
        character_info.palette = _folderpath .. "V3.png"
    end
    if character:get_rank() == Rank.Rare2 then
        character_info.hp = 260
        character_info.damage = 160
        character_info.palette = _folderpath .. "Rare2.png"
    end
    if character:get_rank() == Rank.SP then
        character_info.hp = 300
        character_info.damage = 200
        character_info.palette = _folderpath .. "SP.png"
    end
    if character:get_rank() == Rank.NM then
        character_info.hp = 500
        character_info.damage = 300
        character_info.palette = _folderpath .. "NM.png"
    end
    shared_package_init(character, character_info)
end
