--ID of the package
local package_id = "com.louise.Elemperor"
-- prefix of the character id
local character_id = "com.louise.enemy."

function package_requires_scripts()
  --Define characters here.
  Engine.define_character(character_id .. "Elemperor", _modpath .. "Elemperor")
end

--package init.
function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Elemperor")
  package:set_description("The Emperor of the Elements has returned.")
  package:set_speed(1)
  package:set_attack(0)
  package:set_health(0)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

-- setup the test package
function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "Elemperor", Rank.NM)
  spawner:spawn_at(6, 2)
  mob:get_field():tile_at(6, 2):set_state(TileState.Lava)
  local spawner = mob:create_spawner(character_id .. "Elemperor", Rank.Rare2)
  spawner:spawn_at(5, 1)
  mob:get_field():tile_at(5, 1):set_state(TileState.Poison)
  local spawner = mob:create_spawner(character_id .. "Elemperor", Rank.SP)
  spawner:spawn_at(5, 3)
  mob:get_field():tile_at(5, 3):set_state(TileState.Grass)
end
