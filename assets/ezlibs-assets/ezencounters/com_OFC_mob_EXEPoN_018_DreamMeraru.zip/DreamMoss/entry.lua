local shared_package_init = include("../shared/entry.lua")

function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.OFC.char.EXEPoN-018-DreamMoss"}
            local aliases = {["DreamMoss"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "DremMoss",
        hp = 90,
        damage = 20,
        palette = _folderpath.."battle_v1.palette.png",
        element = Element.Wood,
        height = 44,
        frames_between_actions = 30,
        move_speed = 30,
        attack_frame = 10,
        thunderball_speed = 80,
    }
    if character:get_rank() == Rank.V1 then
        character_info.name = "DreamMoss"
    elseif character:get_rank() == Rank.V2 then
        character_info.hp = 140
        character_info.damage = 50
        character_info.palette = _folderpath.."battle_v2.palette.png"
        character_info.move_speed = 25
        character_info.attack_frame = 9
    elseif character:get_rank() == Rank.V3 then
        character_info.hp = 190
        character_info.damage = 90
        character_info.palette = _folderpath.."battle_v3.palette.png"
        character_info.move_speed = 20
        character_info.attack_frame = 8
    elseif character:get_rank() == Rank.SP then
        character_info.hp = 260
        character_info.damage = 120
        character_info.palette = _folderpath.."battle_sp.palette.png"
        character_info.move_speed = 15
        character_info.attack_frame = 7
    end
    shared_package_init(character, character_info)
end
