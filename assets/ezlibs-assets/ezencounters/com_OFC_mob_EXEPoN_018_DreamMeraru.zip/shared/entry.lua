local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")

local CHARACTER_ANIMATION = _folderpath.."battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.grayscaled.png")

local FLAMETOWER_TEXTURE = Engine.load_texture(_folderpath.."flametower.png")
local FLAMETOWER_ANIMPATH = _folderpath.."flametower.animation"
local FLAMETOWER_AUDIO = Engine.load_audio(_folderpath.."EXE4_216.ogg")

local AQUATOWER_TEXTURE = Engine.load_texture(_folderpath.."aquatower.png")
local AQUATOWER_ANIMPATH = _folderpath.."aquatower.animation"
local AQUATOWER_AUDIO = Engine.load_audio(_folderpath.."EXE4_332.ogg")

local THUNDERBALL_TEXTURE = Engine.load_texture(_folderpath.."thunderball.png")
local THUNDERBALL_ANIMPATH = _folderpath.."thunderball.animation"
local THUNDERBALL_AUDIO = Engine.load_audio(_folderpath.."EXE4_72.ogg")

local WOODYTOWER_TEXTURE = Engine.load_texture(_folderpath.."woodytower.png")
local WOODYTOWER_ANIMPATH = _folderpath.."woodytower.animation"
local WOODYTOWER_AUDIO = Engine.load_audio(_folderpath.."EXE4_287.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

--possible states for character
local states = { IDLE = 1, MOVE = 2, WAIT = 3 }
local debug = false


function debug_print(str)
    if debug then
        print("[DreamMeraru] "..str)
    end
end

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    -- Load extra resources
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = character_info.damage
    self:set_element(character_info.element)
    self.element = character_info.element
    self.thunderball_speed = character_info.thunderball_speed
    self:share_tile(false)
    self:set_explosion_behavior(3, 1, false)
    self:set_offset(0, 0)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.attack_frame = character_info.attack_frame
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.started = false
    self.idle_frames = 8
    self.move_direction = Direction.Up
    self.move_speed = character_info.move_speed
    --self.defense = Battle.DefenseVirusBody.new()
    --self:add_defense_rule(self.defense)
    self.reached_edge = false
    self.has_attacked_once = false

    --state IDLE
    self.action_idle = function(frame)
        if (frame == self.idle_frames) then
            --choose move direction
            self.animation:set_state("IDLE")
            self.animation:set_playback(Playback.Loop)
            self.set_state(states.MOVE)
        end
    end

    self.turn = function()
        debug_print("turned")
        self.move_direction = Direction.reverse(self.move_direction)
    end

    --state MOVE
    self.action_move = function(frame)
        if frame == 1 then
            --get target to slide to
            local target_tile = self:get_tile(self.move_direction, 1)
            debug_print("Current tile "..Tiletostring(self:get_tile()))
            debug_print("Target = "..Tiletostring(target_tile))
            debug_print("Direction = "..directiontostring(self.move_direction))
            --if not free, change direction.
            if not is_tile_free_for_movement(target_tile, self) then
                self.turn()
                local turned_tile = self:get_tile(self.move_direction, 1)
                if (is_tile_free_for_movement(turned_tile, self)) then
                    --free to move to the turned tile, otherwise stuck.
                    self.set_state(states.MOVE)
                end
            end
            self:slide(target_tile, frames(self.move_speed), frames(5), ActionOrder.Immediate, nil)

        end
        if frame >= self.move_speed and not self:is_sliding() then
            debug_print(tostring(self.wait_tiles))
            if self.wait_tiles == 0 then
                --once has moved enough tiles, attack
                self.attack()
                self.set_state(states.WAIT)
                self.wait_tiles = math.random(2, 4)
            else
                self.wait_tiles = self.wait_tiles - 1
                self.set_state(states.MOVE)
            end
        end
    end

    --state WAIT
    self.action_wait = function(frame)
        if (frame == 90) then

            self.set_state(states.IDLE)
        end
    end

    --Utility to set the update state, and reset frame counter
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_wait }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            --This runs once the battle is started
            self.current_direction = self:get_facing()
            self.started = true
            self.set_state(states.IDLE)
            self.wait_tiles = math.random(2, 4)
        else
            --On every frame, we will call the state action func.
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    --state ATTACK
    self.attack = function()
        self.has_attacked_once = true
        self.animation:set_state("ATTACK")

        self.animation:on_frame(6, function()
            debug_print("attacking")
            --create_flametower(self, self:get_team(), self:get_facing(), self:get_field(), self:get_tile(self:get_facing(), 1), self.damage)
            if self.element ~= Element.Elec then
                create_tower(self, self:get_tile(self:get_facing(), 1), self.damage, self.element)
            else
                create_thunderball(self, self:get_tile(self:get_facing(), 1), self.damage, self.element)
            end
            self.set_state(states.WAIT)
        end)
    end

    function Tiletostring(tile)
        return "Tile: ["..tostring(tile:x())..","..tostring(tile:y()).."]"
    end

    function directiontostring(dir)
        if dir == Direction.Up then return "Up"
        elseif dir == Direction.Down then return "Down"
        end
    end

end

--Checks if the tile in 2 given directions is free and returns that direction
function get_free_direction(tile, direction1, direction2)
    if (not tile:get_tile(direction1, 1):is_edge()) then
        return direction1
    else
        return direction2
    end
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() or tile:is_reserved({ character:get_id(), character._reserver }) then
        return false
    end
    if tile:is_edge() or not tile:is_walkable() then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

function find_target(self)
    --Finds the nearest target
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    local target_character = nil
    if #target_list > 0 then
        target_character = target_list[1]
    else
        target_character = self:get_current_tile()
    end
    return target_character;
end

function getNextTile(direction, spell)
    --Chooses next tile for tower
    local tile = spell:get_current_tile():get_tile(direction, 1)
    local target_movement_tile = tile
    local target_character = find_target(spell)
    local target_character_tile = target_character:get_current_tile()
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down,1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up,1)
    end
    return target_movement_tile;
end

function create_flametower(user, team, facing, field, tile, damage)
    --Creates a FlameTower
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

	    local spell = Battle.Spell.new(team)
	    spell:set_hit_props(
            HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                Element.Fire,
                user:get_id(), 
                Drag.None
            )
        )
	    spell:set_facing(facing)
        spell:never_flip(true)
        spell:set_offset(0, 3*2*-1)
        spell.attacking = false
        spell.spawn_next = true
	    local sprite = spell:sprite()
        sprite:set_texture(FLAMETOWER_TEXTURE, true)
	    sprite:set_layer(-3)
        local anim = spell:get_animation()
	    anim:load(FLAMETOWER_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(2, function()
            spell.attacking = true
        end)
        anim:on_frame(user.attack_frame, function() --14, 16, 18, 20, 22
            next_tile = getNextTile(facing, spell)
        end)
        anim:on_frame(user.attack_frame+6, function() --20, 22, 24, 26, 28
            tile = next_tile
            --[[if spell:get_current_tile():find_characters(query) <= 0 then
                spawn_next()
            end]]
            if spell.spawn_next then
                spawn_next()
            end
        end, true)
        anim:on_complete(function()
            spell:delete()
        end)
        local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
        spell.on_spawn_func = function(self)
            Engine.play_audio(FLAMETOWER_AUDIO, AudioPriority.Low)
        end
	    spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            local ref = self
            if ref.spawn_next then
                if #self_tile:find_characters(query_TeamHP) > 0 then
                    ref.spawn_next = false
                end
            end
            if ref.attacking then
                self_tile:attack_entities(self)
                spell:highlight_tile(Highlight.Solid)
			    if self_tile ~= nil and
			    	not self_tile:is_edge() and
			    	#self_tile:find_characters(query_TeamHP) <= 0 and 
			    	#self_tile:find_obstacles(query_TeamHP) <= 0 and 
			    	self_tile:get_state() == TileState.Grass
			    	then
			    	self_tile:set_state(TileState.Normal)
			    end
            end
        end
	    spell.collision_func = function(self, ent)
            --
	    end
        spell.attack_func = function(self, ent)
            create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "2", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            if Battle.Obstacle.from(ent) == nil then
                --[[
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
                ]]
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end
	    spell.battle_end_func = function(self)
	    	self:delete()
	    end
	    spell.can_move_to_func = function(tile)
            return true
        end
        spell.delete_func = function(self)
	    	self:erase()
        end
	    field:spawn(spell, tile)
    end
    spawn_next()
end

function create_tower(user, tile, damage, element)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        local team = user:get_team()
        local field = user:get_field()
        local facing = user:get_facing()

	    local spell = Battle.Spell.new(team)
	    spell:set_hit_props(
            HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                element,
                user:get_id(), 
                Drag.None
            )
        )
	    spell:set_facing(facing)
        spell:never_flip(true)
        spell:set_offset(0, 3*2*-1)
        spell.attacking = false
        spell.spawn_next = true
        --spell.attacked = false
        local new_dir = facing
	    local sprite = spell:sprite()
        local texture = nil
        if      element == Element.Fire then
            texture = FLAMETOWER_TEXTURE
        elseif  element == Element.Aqua then
            texture = AQUATOWER_TEXTURE
        elseif  element == Element.Wood then
            texture = WOODYTOWER_TEXTURE
        end
        sprite:set_texture(texture, true)
	    sprite:set_layer(-3)
        local anim = spell:get_animation()
        local animpath = nil
        if      element == Element.Fire then
            animpath = FLAMETOWER_ANIMPATH
        elseif  element == Element.Aqua then
            animpath = AQUATOWER_ANIMPATH
        elseif  element == Element.Wood then
            animpath = WOODYTOWER_ANIMPATH
        end
	    anim:load(animpath)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(2, function()
            spell.attacking = true
        end)
        --[[
        local spawn_frame = nil
        if      element == Element.Aqua then
            spawn_frame = 11
        elseif  element == Element.Wood then
            spawn_frame = 7
        end
        anim:on_frame(spawn_frame, function()
            local u_y = user:get_tile():y()
            local y = spell:get_tile():y()
            local dif = u_y - y
            if      dif > 0 then 
                new_dir = Direction.join(facing, Direction.Down)
            elseif  dif < 0 then 
                new_dir = Direction.join(facing, Direction.Up)
            end
	    	tile = tile:get_tile(new_dir, 1)
            if spell.spawn_next then
                spawn_next()
            end
        end)
        ]]
        local spawn_frame1 = nil
        local spawn_frame2 = nil
        if      element == Element.Fire then
            spawn_frame1 = user.attack_frame
            spawn_frame2 = user.attack_frame+6
        elseif  element == Element.Aqua then
            spawn_frame1 = 4
            spawn_frame2 = user.attack_frame
        elseif  element == Element.Wood then
            spawn_frame1 = 6
            spawn_frame2 = user.attack_frame
        end
        anim:on_frame(spawn_frame1, function()
            next_tile = getNextTile(facing, spell)
        end)
        anim:on_frame(spawn_frame2, function()
            tile = next_tile
            --[[if spell:get_current_tile():find_characters(query) <= 0 then
                spawn_next()
            end]]
            if spell.spawn_next then
                spawn_next()
            end
        end, true)
        anim:on_complete(function()
            spell:delete()
        end)
        local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
        spell.on_spawn_func = function(self)
            if      element == Element.Fire then
                Engine.play_audio(FLAMETOWER_AUDIO, AudioPriority.Low)
            elseif  element == Element.Aqua then
                Engine.play_audio(AQUATOWER_AUDIO, AudioPriority.Low)
            elseif  element == Element.Wood then
                Engine.play_audio(WOODYTOWER_AUDIO, AudioPriority.Low)
            end
        end
	    spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            local ref = self
            if ref.attacking then
                self_tile:attack_entities(self)
                spell:highlight_tile(Highlight.Solid)
                if not spell:is_deleted() then
			        if 		element == Element.Aqua then
			        	if self_tile ~= nil and
			        		not self_tile:is_edge() and
			        		#self_tile:find_characters(query_TeamHP) <= 0 and 
			        		#self_tile:find_obstacles(query_TeamHP) <= 0 and 
			        		self_tile:get_state() == TileState.Lava
			        		then
			        		self_tile:set_state(TileState.Normal)
			        	end
			        elseif	element == Element.Fire then
			        	if self_tile ~= nil and
			        		not self_tile:is_edge() and
			        		#self_tile:find_characters(query_TeamHP) <= 0 and 
			        		#self_tile:find_obstacles(query_TeamHP) <= 0 and 
			        		self_tile:get_state() == TileState.Grass
			        		then
			        		self_tile:set_state(TileState.Normal)
			        	end
			        end
                end
            end
            if ref.spawn_next then
                if #self:get_current_tile():find_characters(query_TeamHP) > 0 then
                    ref.spawn_next = false
                end
            end
        end
	    spell.collision_func = function(self, ent)
	    end
        spell.attack_func = function(self, ent)
            --ref.attacked = true
            if     element == Element.Fire then
                create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "2", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            elseif element == Element.Aqua then
                create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "3", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            end
            if Battle.Obstacle.from(ent) == nil then
                --[[
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
                ]]
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end
	    spell.battle_end_func = function(self)
	    	self:delete()
	    end
	    spell.can_move_to_func = function(tile)
            return true
        end
        spell.delete_func = function(self)
	    	self:erase()
        end
	    field:spawn(spell, tile)
    end
    spawn_next()
end

function create_thunderball(self, tile, damage, element)
    if not tile or tile:is_edge() then return end

    local team = self:get_team()
    local field = self:get_field()
    local facing = self:get_facing()

    local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Stun, 
            element,
            self:get_id(), 
            Drag.None
        )
    )
	spell:set_facing(facing)
    spell:never_flip(true)
    spell:set_offset(0, (12*2)*-1)
    spell.moves = 7
    spell.target = nil
    spell.speed = self.thunderball_speed
    spell.lifetime = spell.moves * spell.speed
    local sprite = spell:sprite()
    sprite:set_texture(THUNDERBALL_TEXTURE, true)
	sprite:set_layer(-3)
    local anim = spell:get_animation()
    anim:load(THUNDERBALL_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:set_playback(Playback.Loop)

    local function find_enemy(spell)
        local team = spell:get_team()

        local list = spell:get_field():find_nearest_characters(spell, function(c)
            return c:get_team() ~= team
        end)

        spell.target = list[1]
    end

    spell.last_target_y = 1
    local function determine_next_tile(spell)
        local t = spell:get_current_tile()
        local target = spell.target:get_current_tile()
        local dest = nil

        local distance_check = target:x() - t:x()

        if distance_check < 0 then 
            targetX = -1
        elseif distance_check > 0 then 
            targetX = 1
        else 
            targetX = 0 
        end

        if targetX ~= 0 then 
            dest = field:tile_at((t:x() + targetX), t:y())
        else -- We're lined up horizontally
            distance_check = target:y() - t:y()
            if distance_check < 0 then 
                targetY = -1
            elseif distance_check > 0 then 
                targetY = 1
            else 
                targetY = spell.last_target_y
            end

            spell.last_target_y = targetY
            dest = field:tile_at(t:x(), t:y() + targetY)
        end

        return dest
    end

    spell.on_spawn_func = function(self)
        Engine.play_audio(THUNDERBALL_AUDIO, AudioPriority.Low)
    end

    spell.update_func = function(self)
        local target = self.target
        
        if not target or target:is_deleted() or not target:get_current_tile() then 
            find_enemy(self)
            target = self.target
        end

        local tile = self:get_current_tile()
        tile:attack_entities(self)
        tile:highlight(Highlight.Solid)

        if not target then return end

        if self:is_sliding() == false then
            --if self.moves <= 0 then 
            --   self:delete()
            --end
            if tile:is_edge() then 
                self:delete()
            end
            
            local dest = determine_next_tile(self)
            
            if dest then 
                self:slide(dest, frames(self.speed), frames(0), ActionOrder.Voluntary, function()
                -- self.moves = self.moves - 1
                end)
            end
        end

        self.lifetime = self.lifetime - 1
        if self.lifetime <= 0 then 
            self:delete()
        end
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    spell.attack_func = function(self, ent)
        create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "4", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
            --[[
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
            ]]
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end

    spell.battle_end_func = function(self)
        self:hide()
		self:delete()
	end

    spell.collision_func = function(self)
        self:hide()
        self:delete()
    end

    spell.delete_func = function(self)
        self:erase()
    end

    field:spawn(spell, tile)
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    
    return hitfx
end

return package_init
