local package_id = "com.Dawn.Viruses.FighterPlane"
local character_id = "com.Dawn.Viruses.Enemy.FighterPlane"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("FighterPlane")
  package:set_description("Eyes to the skies!")
  package:set_speed(1)
  package:set_attack(20)
  package:set_health(140)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  local field = mob:get_field()

  local tile = field:tile_at(4, 2)

  if not tile:is_walkable() then
    tile:set_state(TileState.Normal)
  end

  mob
    :create_spawner(character_id, Rank.V1)
    :spawn_at(5, 2)
  mob
    :create_spawner(character_id, Rank.V2)
    :spawn_at(4, 1)
  mob
    :create_spawner(character_id, Rank.V3)
    :spawn_at(6, 3)
  
end
