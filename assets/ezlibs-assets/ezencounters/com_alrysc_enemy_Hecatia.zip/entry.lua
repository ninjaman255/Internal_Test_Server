local package_id = "com.alrysc.enemy.Hecatia"
local character_id = "com.alrysc.enemy.HecatiaEnemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."enemy")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Hecatia")
    package:set_description("Planetary attack!")
    package:set_speed(1)
    package:set_attack(120)
    package:set_health(3500)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 

    local texPath = _modpath.."bg.png"
    local animPath = _modpath.."bg.animation"
    mob:set_background(texPath, animPath, 0.3334, 0.3334)
    mob:stream_music(_modpath.."VSnavi.ogg", 13896, 32307)
   -- 612820,2037590 
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)

    local field = mob:get_field()
    field:tile_at(4, 1):set_state(TileState.Empty)
    field:tile_at(4, 2):set_state(TileState.Empty)
    field:tile_at(4, 3):set_state(TileState.Empty)
    field:tile_at(5, 1):set_state(TileState.Empty)
    field:tile_at(5, 3):set_state(TileState.Empty)
    field:tile_at(6, 1):set_state(TileState.Empty)
    field:tile_at(6, 2):set_state(TileState.Empty)
    field:tile_at(6, 3):set_state(TileState.Empty)

end