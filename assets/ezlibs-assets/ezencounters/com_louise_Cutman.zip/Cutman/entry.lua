local shared_package_init = include("./character.lua")
function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.enemy.Cutman"}
            local aliases = {["CutMan"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Cutman",
        hp = 900,
        scissor_damage = 80,
        boomerang_damage = 100,
        cut_damage = 100,
        palette = _folderpath .. "palette.png",
        height = 44,
        frames_between_actions = 34,
        fast_hop_frames = 4,
        scissor_max = 1
    }
    if character:get_rank() == Rank.EX then
        character_info.hp = 1200
        character_info.scissor_damage = 160
        character_info.boomerang_damage = 140
        character_info.cut_damage = 150
        character_info.scissor_max = 2
    end
	if character:get_rank() == Rank.SP then
        character_info.hp = 1500
        character_info.scissor_damage = 200
        character_info.boomerang_damage = 280
        character_info.cut_damage = 250
        character_info.scissor_max = 2
    end
    if character:get_rank() == Rank.NM then
        character_info.damage = 250
        character_info.palette = _folderpath .. "DS.png"
        character_info.hp = 2500
        character_info.scissor_damage = 240
        character_info.boomerang_damage = 260
        character_info.cut_damage = 300
        character_info.scissor_max = 3
        character_info.frames_between_actions = 23
    end
    shared_package_init(character, character_info)
end
