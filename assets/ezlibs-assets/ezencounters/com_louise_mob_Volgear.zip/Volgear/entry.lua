local shared_package_init = include("../shared/entry.lua")

function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.char.Volgear"}
            local aliases = {["Volgear"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name="VolGear",
        hp=80,
        damage=20,
        palette=_folderpath.."battle_v1.palette.png",
        height=20,
        cascade_frame = 26,
        flame_animation="flame.animation",
        move_delay = 48,
        can_guard = true
    }
    if character:get_rank() == Rank.V2 then
        character_info.damage = 50
        character_info.palette=_folderpath.."battle_v2.palette.png"
        character_info.hp = 120
        character_info.cascade_frame = 24
        character_info.move_delay = 42
    elseif character:get_rank() == Rank.V3 then
        character_info.damage = 100
        character_info.palette=_folderpath.."battle_v3.palette.png"
        character_info.hp = 160
        character_info.cascade_frame = 22
        character_info.move_delay = 34
    elseif character:get_rank() == Rank.SP then
        character_info.damage = 150
        character_info.palette=_folderpath.."battle_vsp.palette.png"
        character_info.hp = 200
        character_info.cascade_frame = 20
        character_info.move_delay = 48
    end
    shared_package_init(character,character_info)
end
