local package_id = "com.OFC.mob.EXE6-023-Gunner"
local character_id = "com.OFC.char.EXE6-023-Gunner"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Gunner")
end

function package_init(package)
    --print('package init for '..package_id)
    package:declare_package_id(package_id)
    package:set_name("Gunner (EXE6)")
    package:set_description("Test fight with\nthe Gunner family\nfrom EXE6")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local test_spawner = mob:create_spawner(character_id, Rank.V1)
          test_spawner:spawn_at(4, 1)
          test_spawner = mob:create_spawner(character_id, Rank.V2)
          test_spawner:spawn_at(5, 2)
          test_spawner = mob:create_spawner(character_id, Rank.V3)
          test_spawner:spawn_at(6, 3)
end