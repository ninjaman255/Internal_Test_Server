local package_id = "com.Dawn.Requested.Catack"
local character_id = "com.Dawn.Requested.Enemy.Catack"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."catack")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Catack")
  package:set_description("Battletanx!")
  -- package:set_speed(999)
  -- package:set_attack(999)
  -- package:set_health(9999)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  mob
    :create_spawner(character_id, Rank.V1)
    :spawn_at(4, 2)
  mob
    :create_spawner(character_id, Rank.V2)
    :spawn_at(4, 1)
  mob
    :create_spawner(character_id, Rank.V3)
    :spawn_at(4, 3)
  mob
    :create_spawner(character_id, Rank.SP)
    :spawn_at(6, 2)
end
