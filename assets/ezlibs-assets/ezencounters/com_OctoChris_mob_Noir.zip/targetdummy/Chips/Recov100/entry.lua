function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-162-Recovery100")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'I', 'Q', 'Z'})

    local props = package:get_card_props()
    props.shortname = "Recov100"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    props.description = "Restore 100HP to self!"
	props.card_class = CardClass.Standard
	props.limit = 2
	props.can_boost = false
end

local chip = {}
function chip.card_create_action(actor)
	props = Battle.CardProperties.new()
    props.shortname = "Recov100"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_metadata(props)
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        local step1 = Battle.Step.new()
        step1.update_func = function(self, dt)
            local recov = create_recov("DEFAULT", user)
            actor:get_field():spawn(recov, actor:get_current_tile())
            actor:set_health(actor:get_health() + 100)
            self:complete_step()
        end
        self:add_step(step1)
	end
    return action
end

function create_recov(animation_state, user)
    local spell = Battle.Spell.new(Team.Other)

    spell:set_texture(Engine.load_texture(_folderpath.."spell_heal.png"), true)
	spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            0,
			Hit.None,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	spell:sprite():set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_folderpath.."spell_heal.animation")
    anim:set_state(animation_state)
	spell:get_animation():on_complete(
		function()
			spell:erase()
		end
	)

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(Engine.load_audio(_folderpath.."sfx.ogg"), AudioPriority.High)

    return spell
end

return chip