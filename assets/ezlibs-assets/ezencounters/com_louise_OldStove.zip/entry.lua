local package_id = "com.louise.OldStove"
local character_id = "com.louise.enemy."

-- To spawn this enemy use
-- com.louise.enemy.OldStove

function package_requires_scripts()
  Engine.define_character(character_id .. "OldStove", _modpath .. "OldStove")
  Engine.define_character(character_id .. "OldHeater", _modpath .. "OldHeater")
  Engine.define_character(character_id .. "OldBurner", _modpath .. "OldBurner")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("OldStove")
  package:set_description("An old stove")
  package:set_speed(1)
  package:set_attack(20)
  package:set_health(80)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)

  local spawner = mob:create_spawner(character_id .. "OldStove", Rank.V1)
  spawner:spawn_at(4, 1)
  local spawner = mob:create_spawner(character_id .. "OldBurner", Rank.V1)
  spawner:spawn_at(5, 2)
  local spawner = mob:create_spawner(character_id .. "OldStove", Rank.Rare2)
  spawner:spawn_at(6, 3)

end
