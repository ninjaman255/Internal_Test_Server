local shared_package_init = include("./character.lua")
local character_id = "com.louise.enemy."
function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.enemy.Corn.BombCorn"}
            local aliases = {["BombCorn"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name="BombCorn",
        hp=150,
        damage=50,
        palette=_folderpath.."V1.png",
        height=44,
        cornshots = 2,
        move_speed = 16
    }
    if character:get_rank() == Rank.SP then
        character_info.damage = 120
        character_info.palette=_folderpath.."SP.png"
        character_info.hp = 270
        character_info.cornshots = 3
    elseif character:get_rank() == Rank.Rare1 then
        character_info.damage = 70
        character_info.palette=_folderpath.."R1.png"
        character_info.hp = 180
        character_info.name="RareCorn"
        character_info.cornshots = 3
    elseif character:get_rank() == Rank.Rare2 then
        character_info.damage = 130
        character_info.palette=_folderpath.."R2.png"
        character_info.hp = 270
        character_info.name="RareCorn"
        character_info.cornshots = 3
        character_info.has_areagrab=true
    end
    shared_package_init(character,character_info)
end
