-- main.lua (Entry Point)
local CameraManager = require("scripts/camera/camera-manager")

-- Initialize the camera system
CameraManager:init()

-- That's it! The system now:
-- 1. Automatically creates camera controllers for each player on join
-- 2. Automatically activates camera control for each player
-- 3. Handles input for camera movement
-- 4. Manages camera position updates

-- Optional: You can still use the CameraManager API if needed
return CameraManager