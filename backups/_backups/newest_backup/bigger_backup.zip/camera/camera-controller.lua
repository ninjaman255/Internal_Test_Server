-- CameraController.lua
local CameraController = {}
local Input = require("scripts/input/input")

local X_CAMERA_ADJUST = 0.05
local Y_CAMERA_ADJUST = 0.05

function CameraController:new(player_id)
    local controller = {
        player_id = player_id,
        player_input_locked = false,
        player_in_control = false,
        current_position = {x = 0, y = 0, z = 100},  -- Current confirmed position
        pending_position = nil,                      -- Position we're trying to move to
        move_speed = 2.0,
        active = false,
        is_moving = {
            left = false,
            right = false,
            up = false,
            down = false
        }
    }
    
    setmetatable(controller, self)
    self.__index = self
    return controller
end

function CameraController:activate(is_player_controlled)
    if is_player_controlled ~= nil then
        self.player_in_control = is_player_controlled
    end
    
    self.player_input_locked = true
    self.player_in_control = true
    self.pending_position = nil  -- Clear any pending position
    self.active = true
    -- Initialize camera at player position
    local player_pos = Net.get_player_position(self.player_id)
    self.current_position = {x = player_pos.x, y = player_pos.y, z = player_pos.z}
    
    -- Initialize movement tracking
    self.is_moving = {
        left = false,
        right = false,
        up = false,
        down = false
    }
    
    print("Camera activated for player " .. self.player_id)
end

function CameraController:deactivate()
    self.player_input_locked = false
    self.player_in_control = false
    self.pending_position = nil  -- Clear any pending position
    self.active = false
    Net.track_with_player_camera(self.player_id)
    Net.unlock_player_input(self.player_id)
    print("Camera deactivated for player " .. self.player_id)
end

function table.contains(tbl, value)
    for _, v in pairs(tbl) do
        if v == value then
            return true
        end
    end
    return false
end

function CameraController:handle_input(event)
    if not self.player_in_control then
        return
    end
    
    print(event)
    
    local new_x = self.current_position.x
    local new_y = self.current_position.y
    local moved = false
    local up_left_found = false
    
    if (table.contains(event.events, "UI Down") or table.contains(event.events, "Move Down") and (table.contains(event.events, "UI Left") or table.contains(event.events, "Move Left"))) then 
        new_x = self.current_position.x - (X_CAMERA_ADJUST / 2)
        new_y = self.current_position.y - (Y_CAMERA_ADJUST)
        print("TABLE CONTAINS DOWN_LEFT")
        up_left_found = true
    end    
    -- Process all button events
    if not up_left_found then
    for i = 1, #event.events do


        local btn = event.events[i]
        
        -- Handle movement based on button state
        if btn.state == 2 or btn.state == 1 then  -- Button pressed/held state
            if btn.name == "UI Left" or btn.name == "Move Left" then
                new_x = self.current_position.x - X_CAMERA_ADJUST
                moved = true
            elseif btn.name == "UI Right" or btn.name == "Move Right" then
                new_x = self.current_position.x + X_CAMERA_ADJUST
                moved = true
            end
            if btn.name == "UI Up" or btn.name == "Move Up" then
                new_y = self.current_position.y - Y_CAMERA_ADJUST
                moved = true
            elseif btn.name == "UI Down" or btn.name == "Move Down" then
                new_y = self.current_position.y + Y_CAMERA_ADJUST
                moved = true
            end
        end
    end
    end
    
    -- Move camera to new position only if we actually need to move
    if moved then
        print("Current position: ", self.current_position)
        self:moveTo(new_x, new_y, self.current_position.z)
    end
end

function CameraController:moveTo(x, y, z)
    -- Set pending position
    self.pending_position = {
        x = x,
        y = y,
        z = z or self.current_position.z or 100
    }
    
    -- Move the player camera
    Net.move_player_camera(self.player_id, x, y, z or self.current_position.z or 100)
    
    -- Update current position to the pending position
    self.current_position = self.pending_position
    self.pending_position = nil  -- Clear pending position
    
    print("Camera moved to: ", self.current_position)
end

function CameraController:relativeMoveTo(dx, dy, dz)
    local new_x = self.current_position.x + (dx or 0)
    local new_y = self.current_position.y + (dy or 0)
    local new_z = self.current_position.z + (dz or 0)
    
    self:moveTo(new_x, new_y, new_z)
end

function CameraController:pan(dx, dy, dz)
    self:relativeMoveTo(dx, dy, dz)
end

function CameraController:setPosition(new_x, new_y, new_z)
    self.current_position.x = new_x or self.current_position.x
    self.current_position.y = new_y or self.current_position.y
    self.current_position.z = new_z or self.current_position.z
    self.pending_position = nil  -- Clear any pending position when setting directly
end

function CameraController:getPosition()
    -- Return a copy of the current position
    return {
        x = self.current_position.x,
        y = self.current_position.y,
        z = self.current_position.z
    }
end

function CameraController:getPendingPosition()
    if self.pending_position then
        return {
            x = self.pending_position.x,
            y = self.pending_position.y,
            z = self.pending_position.z
        }
    end
    return nil
end

function CameraController:hasPendingMove()
    return self.pending_position ~= nil
end

return CameraController