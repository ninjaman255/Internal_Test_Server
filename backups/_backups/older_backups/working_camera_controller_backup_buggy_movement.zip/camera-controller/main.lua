local PlayerControllers = {}
local CAMERA_ADJUST = 0.1
local CameraController = {}

local Camera = Net.EventEmitter.new()
local Input = require("scripts/input/input")

-- Initialize the Input system once
Input.attach_virtual_input_listener({
    left = { "Move Left", "UI Left", "Left" },
    right = { "Move Right", "UI Right", "Right" },
    up = { "Move Up", "UI Up", "Up" },
    down = { "Move Down", "UI Down", "Down" },
    confirm = { "Confirm", "A" },
    cancel = { "Cancel", "B" }
})

function CameraController:Activate(is_player_controlled)
    if is_player_controlled ~= nil then
        self.player_in_control = is_player_controlled
    end
    Camera:emit("Activate", {player_id = self.player_id})  
end

function CameraController:Disable()
    Camera:emit("Disable", {player_id = self.player_id})  
end

function CameraController:new(player_id)
    local controller = {
        player_id = player_id,
        player_input_locked = false,
        player_in_control = false,
        current_camera_position = {x = 0, y = 0, z = 100},
        _attached = true,
        move_speed = 2.0,
        is_moving = {
            left = false,
            right = false,
            up = false,
            down = false
        }
    }

    setmetatable(controller, self)
    self.__index = self
    return controller
end

-- Optional: Add utility functions for camera control
function CameraController:moveTo(x, y, z)
    self:setPosition(x, y, z)
    Net.move_player_camera(self.player_id, x, y, (z or 100))
end

function CameraController:pan(dx, dy, dz)
    self:setPosition(self.current_camera_position.x + (dx or 0), self.current_camera_position.x + (dy or 0), self.current_camera_position.x + (dz or 0))
    Net.move_player_camera(
        self.player_id, 
        self.current_camera_position.x,
        self.current_camera_position.y,
        self.current_camera_position.z
    )
end

function CameraController:setPosition(new_x, new_y, new_z)
    self.current_camera_position.x = new_x
    self.current_camera_position.y = new_y
    self.current_camera_position.z = new_z
end


Camera:on("Activate", function(event)
    local player_id = event.player_id
    local PlayerController = PlayerControllers[player_id]
    print("Activating camera for player " .. player_id)
    
    Net.lock_player_input(player_id)
    Net.unlock_player_camera(player_id)
    PlayerController.player_input_locked = true
    PlayerController.player_in_control = true
    
    -- Initialize camera at player position
    local player_pos = Net.get_player_position(player_id)
    PlayerController:setPosition(player_pos.x, player_pos.y, player_pos.z)
    print(PlayerController.current_camera_position)
    print(player_id .. "'s input is locked for camera control!")
    
    -- Clear any buffered input when activating
    -- Input.consume(controller.player_id)
    
    -- Initialize movement tracking
    PlayerController.is_moving = {
        left = false,
        right = false,
        up = false,
        down = false
    }
    PlayerController.move_speed = 2.0  -- Adjust this for faster/slower movement
end)

Camera:on("Disable", function(event)
    local player_id = event.player_id
    local PlayerController = PlayerControllers[player_id]
    
    Net.unlock_player_input(player_id)
    Net.track_with_player_camera(player_id)
    PlayerController.player_input_locked = false
    PlayerController.player_in_control = false
    
    print(player_id .. "'s input is unlocked!")
end)

Net:on("player_join", function (event)
    local player_camera = CameraController:new(event.player_id)
    if not PlayerControllers[event.player_id] then
        PlayerControllers[event.player_id] = {}
    end

    PlayerControllers[event.player_id] = player_camera
    PlayerControllers[event.player_id]:Activate(true)
end)

Net:on("virtual_input", function(event)
    for player_id, camera in pairs(PlayerControllers) do
        if camera.player_in_control and camera.player_input_locked then
            
            local new_x_adjust
            local new_y_adjust
            -- 1. Check for initial presses using pop()
            --   if Input.pop(player_id, "left") then
            --       new_x_adjust =  -CAMERA_ADJUST
            --       position_changed = true
            --       camera.is_moving.left = true
            --   end
            --   
            --   if Input.pop(player_id, "right") then
            --       new_x_adjust = CAMERA_ADJUST
            --       position_changed = true
            --       camera.is_moving.right = true
            --   end
            --   
            --   if Input.pop(player_id, "up") then
            --       new_y_adjust = -CAMERA_ADJUST
            --       position_changed = true
            --       camera.is_moving.up = true
            --   end
            --   
            --   if Input.pop(player_id, "down") then
            --       new_y_adjust = CAMERA_ADJUST
            --       position_changed = true
            --       camera.is_moving.down = true
            --   end
             -- print(new_x .. new_y)
            
            -- 2. Check for Scroll events (these come from framework when button is held)
            -- The Input system automatically handles Scroll events for directional keys
            -- Each Scroll event should trigger another movement
            
            -- 3. Handle continuous movement while buttons are held down
            -- Use is_down() to check if button is currently pressed
            -- Input.clear_require_release(player_id)
            if Input.pressed(player_id, "left") and not Input.pressed(player_id, "right") then
                new_x_adjust = PlayerControllers[player_id].current_camera_position.x - 0.1
                camera.is_moving.left = true
            elseif Input.pressed(player_id, "right") and not Input.pressed(player_id, "left") then
                new_x_adjust = PlayerControllers[player_id].current_camera_position.x + 0.1
                camera.is_moving.right = true
            else  
                Input.pop(player_id, "left")
                Input.pop(player_id, "right")
                camera.is_moving.left = false
                camera.is_moving.right = false
                new_x_adjust = PlayerControllers[player_id].current_camera_position.x 
            end
            
            if Input.pressed(player_id, "up") and not Input.pressed(player_id, "down") then
                new_y_adjust = PlayerControllers[player_id].current_camera_position.y - 0.1
                camera.is_moving.up = true
            elseif Input.pressed(player_id, "down") and not Input.pressed(player_id, "up") then
                new_y_adjust = PlayerControllers[player_id].current_camera_position.y + 0.1
                camera.is_moving.down = true
            else
                Input.pop(player_id, "up")
                Input.pop(player_id, "down")
                camera.is_moving.up = false
                camera.is_moving.down = false
                new_y_adjust = PlayerControllers[player_id].current_camera_position.y
            end
            
            -- local new_x = PlayerControllers[player_id].current_camera_position.x + new_x_adjust
            -- local new_y = PlayerControllers[player_id].current_camera_position.y + new_y_adjust
            
            -- 4. Only move camera if position changed
                camera:moveTo(
                    new_x_adjust, 
                    new_y_adjust, 
                    camera.current_camera_position.z
                )
            end
        end 
end)

return CameraController