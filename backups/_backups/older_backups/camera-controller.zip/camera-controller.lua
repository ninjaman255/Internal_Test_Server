local CameraController = {}
local Camera = Net.EventEmitter.new()

function CameraController:new(player_id)
    local controller = {
        player_id = player_id,
        player_input_locked = false,
        player_in_control = false,
        current_camera_position = {120, 80, 100},
        _attached = true
    }

    setmetatable(controller, self)
    self.__index = self
    return controller
end

function CameraController:OpenCamera()
  Camera:emit("Open", {player_id = self.player_id, current_camera_pos = self.current_camera_position,})  
end

function CameraController.CloseCamera(player_id)
  Camera:emit("Close", {player_id = player_id})  
end

Camera:on("Open", function(event)
    local player_id = event.player_id
    print(player_id)
    print(event.current_camera_pos)
    Net.lock_player_input(player_id)
    print(player_id .. "'s input is locked!")
end)

Camera:on("Close", function(event)

end)

Net:on("player_join", function (event)
    local player_camera = CameraController:new(event.player_id)
    print(player_camera)
end)

return CameraController