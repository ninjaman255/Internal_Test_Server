function table.contains_deep(t, value)
    if type(t) ~= "table" then return false end

    for _, v in pairs(t) do
        if v == value then
            return true
        elseif type(v) == "table" then
            if table.contains_deep(v, value) then
                return true
            end
        end
    end
    return false
end

local InputReader = {}

InputReader.InputStates = {press = 1, held = 2, released = 3}

InputReader.Buttons = {
    left    = { "UI Left", "Move Left", "Left" },
    right   = { "UI Right", "Move Right", "Right" },
    up      = { "UI Up", "Move Up", "Up" },
    down    = { "UI Down", "Move Down", "Down" },
  
    confirm = { "Confirm", "A", "OK", "Accept", "Use Card" },
    cancel  = { "Cancel", "Back", "B", "Shoot", "Run" },
    option = {"Option", "Special"},
    l_shoulder = {"Shoulder L"},
    r_shoulder = {"Shoulder R"},
    pause = {"Pause"},
    cust_menu = {"Cust Menu"},
    minimap = {"Minimap"}
}


function InputReader.parseEvents(events)
    local buttons = {
        pressed = {},
        held = {},
        released = {}
    }

    for i = 1, #events do
        if events[i].state == 1 then
            table.insert(buttons.pressed, events[i].name) 
        end
        if events[i].state == 2 then
            table.insert(buttons.held, {
                [events[i].name] = {}
            }) 
        end
        if events[i].state == 3 then
            table.insert(buttons.released, events[i].name) 
        end
    end

    return buttons
end



return InputReader