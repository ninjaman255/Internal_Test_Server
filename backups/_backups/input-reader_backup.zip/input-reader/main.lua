local InputReader = require("scripts/input-reader/controller/controller")

local MainEmitter = Net.EventEmitter.new()

Net:on("tick", function (event)
end)

Net:on("player_join", function(event)
    local player_id = event.player_id
    
    -- InputReader.Players[player_id] = {
    --     Active = false,
    --     InputQueue = {}
    -- }
    -- 
    -- print(InputReader.Players)
    Net.lock_player_input(player_id) -- Required to get any readings from virtual_input on handler
end)


Net:on("virtual_input", function(event)
    local player_id = event.player_id
    local events = event.events
    
    local parsed_button_inputs = InputReader.parseEvents(events)

    MainEmitter:emit("validate_inputs", {player_id = player_id, parsed_buttons = parsed_button_inputs})
    --[[
        Events structure:
        [index_#](int) = {
            ["name"] = "BUTTON NAME"
            ["state"] = InputReader.InputStates
        }
    --]]
    -- print(events) -- table of events
    
end)

MainEmitter:on("validate_inputs", function(event)
    local player_id = event.player_id
    local buttons = event.parsed_buttons
    print(player_id)
    print(buttons)
end)
