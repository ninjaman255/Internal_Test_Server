-- sprite-widget/subsystems/layout.lua
-- Layout class

local Layout = {}
Layout.__index = Layout

-- Alignment parsing
local function parse_alignment(alignment)
    local vertical, horizontal = "top", "left"
    
    if alignment then
        local parts = {}
        for part in alignment:gmatch("[^%-]+") do
            table.insert(parts, part:lower())
        end
        
        if #parts >= 2 then
            vertical = parts[1]
            horizontal = parts[2]
        elseif #parts == 1 then
            vertical = "center"
            horizontal = "center"
        end
    end
    
    return vertical, horizontal
end

-- Constructor
function Layout.new(options)
    options = options or {}
    
    local self = setmetatable({}, Layout)
    
    self.type = options.type or "absolute"
    self.x = options.x or 0  -- Logical coordinates (240x160 space)
    self.y = options.y or 0  -- Logical coordinates (240x160 space)
    self.z = options.z or 0
    self.spacing = options.spacing or { x = 0, y = 0 }  -- Logical spacing
    self.max_children = options.max_children or math.huge
    self.alignment = options.alignment or "top-left"
    self.children = {}
    self.parent = nil
    self._dirty = false
    self._id = options.id or tostring(math.random(100000, 999999))
    self._player_id = options.player_id
    
    return self
end

-- Dirty state management
function Layout:_markDirty()
    self._dirty = true
end

-- Child management
function Layout:add_child(sprite_obj)
    if #self.children >= self.max_children then
        print("WARNING: Layout max children reached")
        return false
    end
    
    table.insert(self.children, sprite_obj)
    sprite_obj.layout_parent = self
    self._dirty = true
    
    self:_update_children()
    return true
end

function Layout:remove_child(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            table.remove(self.children, i)
            child.layout_parent = nil
            self._dirty = true
            return true
        end
    end
    return false
end

function Layout:clear()
    for _, child in ipairs(self.children) do
        child.layout_parent = nil
    end
    self.children = {}
    self._dirty = true
end

-- Layout properties
function Layout:set_position(x, y)
    self.x = x  -- Logical coordinates
    self.y = y  -- Logical coordinates
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_alignment(alignment)
    self.alignment = alignment
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_spacing(x, y)
    self.spacing.x = x or self.spacing.x  -- Logical spacing
    self.spacing.y = y or self.spacing.y  -- Logical spacing
    self._dirty = true
    self:_update_children()
    return self
end

-- Child ordering
function Layout:swap_children(index1, index2)
    if index1 >= 1 and index1 <= #self.children and
       index2 >= 1 and index2 <= #self.children then
        self.children[index1], self.children[index2] = 
            self.children[index2], self.children[index1]
        self._dirty = true
        self:_update_children()
        return true
    end
    return false
end

function Layout:bring_child_to_front(sprite_obj)
    local index = self:get_child_index(sprite_obj)
    if index > 0 then
        return self:move_child(index, #self.children)
    end
    return false
end

function Layout:send_child_to_back(sprite_obj)
    local index = self:get_child_index(sprite_obj)
    if index > 0 then
        return self:move_child(index, 1)
    end
    return false
end

-- Query methods
function Layout:get_child_count()
    return #self.children
end

function Layout:get_child_at(index)
    return self.children[index]
end

function Layout:get_child_index(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            return i
        end
    end
    return -1
end

-- Alignment calculations
function Layout:_calculate_alignment_offset(total_width, total_height, vertical, horizontal)
    local offset_x, offset_y = 0, 0
    
    if horizontal == "center" then
        offset_x = - total_width / 2
    elseif horizontal == "right" then
        offset_x = - total_width
    end
    
    if vertical == "center" then
        offset_y = -total_height / 2
    elseif vertical == "bottom" then
        offset_y = -total_height
    end
    
    return offset_x, offset_y
end

-- Update children positions
function Layout:_update_children()
    if not self._dirty or #self.children == 0 then return end
    
    local vertical, horizontal = parse_alignment(self.alignment)
    
    if self.type == "horizontal" then
        self:_arrange_horizontal(self.x, self.y, 
                                self.spacing.x, self.spacing.y,
                                vertical, horizontal)
    elseif self.type == "vertical" then
        self:_arrange_vertical(self.x, self.y,
                              self.spacing.x, self.spacing.y,
                              vertical, horizontal)
    elseif self.type == "grid" then
        self:_arrange_grid(self.x, self.y,
                          self.spacing.x, self.spacing.y,
                          vertical, horizontal)
    elseif self.type == "relative" then
        self:_arrange_relative(self.x, self.y)
    elseif self.type == "absolute" then
        self:_arrange_absolute(self.x, self.y)
    end
    
    self._dirty = false
end

-- Layout arrangement methods
function Layout:_arrange_horizontal(x, y, spacing_x, spacing_y, vertical, horizontal)
    local total_width = 0
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64  -- Scaled logical width
        total_width = total_width + child_width + spacing_x
    end
    
    if #self.children > 0 then
        total_width = total_width - spacing_x
    end
    
    local align_offset_x, align_offset_y = self:_calculate_alignment_offset(
        total_width, 0, vertical, horizontal
    )
    
    local current_x = x + align_offset_x
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64  -- Scaled logical width
        local child_height = child:get_scaled_height() or 64  -- Scaled logical height
        
        local child_y = y + align_offset_y
        if vertical == "center" then
            child_y = child_y + (child_height / 2)
        elseif vertical == "bottom" then
            child_y = child_y + child_height
        end
        
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(current_x), transform(child_y))
        current_x = current_x + child_width + spacing_x
    end
end

function Layout:_arrange_vertical(x, y, spacing_x, spacing_y, vertical, horizontal)
    local total_height = 0
    for _, child in ipairs(self.children) do
        local child_height = child:get_scaled_height() or 64  -- Scaled logical height
        total_height = total_height + child_height + spacing_y
    end
    
    if #self.children > 0 then
        total_height = total_height - spacing_y
    end
    
    local align_offset_x, align_offset_y = self:_calculate_alignment_offset(
        0, total_height, vertical, horizontal
    )
    
    local current_y = y + align_offset_y
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64  -- Scaled logical width
        local child_height = child:get_scaled_height() or 64  -- Scaled logical height
        
        local child_x = x + align_offset_x
        if horizontal == "center" then
            child_x = child_x + (child_width / 2)
        elseif horizontal == "right" then
            child_x = child_x + child_width
        end
        
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(child_x), transform(current_y))
        current_y = current_y + child_height + spacing_y
    end
end

function Layout:_arrange_grid(x, y, spacing_x, spacing_y, vertical, horizontal)
    if #self.children == 0 then return end
    
    -- Calculate grid dimensions
    local grid_cols = math.ceil(math.sqrt(#self.children))
    if grid_cols == 0 then grid_cols = 1 end
    
    local grid_rows = math.ceil(#self.children / grid_cols)
    
    -- Find max child dimensions (scaled logical)
    local max_child_width = 0
    local max_child_height = 0
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64  -- Scaled logical width
        local child_height = child:get_scaled_height() or 64  -- Scaled logical height
        max_child_width = math.max(max_child_width, child_width)
        max_child_height = math.max(max_child_height, child_height)
    end
    
    -- Calculate total dimensions (logical)
    local total_width = (max_child_width * grid_cols) + (spacing_x * (grid_cols - 1))
    local total_height = (max_child_height * grid_rows) + (spacing_y * (grid_rows - 1))
    
    local align_offset_x, align_offset_y = self:_calculate_alignment_offset(
        total_width, total_height, vertical, horizontal
    )
    
    -- Position children
    for i, child in ipairs(self.children) do
        local row = math.floor((i - 1) / grid_cols)
        local col = (i - 1) % grid_cols
        
        local child_x = x + align_offset_x + 
                       (col * (max_child_width + spacing_x))
        local child_y = y + align_offset_y + 
                       (row * (max_child_height + spacing_y))
        
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(child_x), transform(child_y))
    end
end

function Layout:_arrange_relative(x, y)
    for _, child in ipairs(self.children) do
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(
            transform(x + (child._obj.offset_x or 0)),
            transform(y + (child._obj.offset_y or 0))
        )
    end
end

function Layout:_arrange_absolute(x, y)
    for _, child in ipairs(self.children) do
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(x), transform(y))
    end
end

-- Move child (helper for bring_to_front/send_to_back)
function Layout:move_child(from_index, to_index)
    if from_index >= 1 and from_index <= #self.children and
       to_index >= 1 and to_index <= #self.children then
        local child = table.remove(self.children, from_index)
        table.insert(self.children, to_index, child)
        self._dirty = true
        self:_update_children()
        return true
    end
    return false
end

-- Add child at index
function Layout:add_child_at(sprite_obj, index)
    if #self.children >= self.max_children then
        return false
    end
    
    index = math.min(math.max(1, index), #self.children + 1)
    table.insert(self.children, index, sprite_obj)
    sprite_obj.layout_parent = self
    self._dirty = true
    self:_update_children()
    return true
end

-- Remove child at index
function Layout:remove_child_at(index)
    if index >= 1 and index <= #self.children then
        local child = self.children[index]
        child.layout_parent = nil
        table.remove(self.children, index)
        self._dirty = true
        return child
    end
    return nil
end

return Layout