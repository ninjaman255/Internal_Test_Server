-- sprite-widget/sprite-displayer.lua
-- Main API Gateway following Displayer-like architecture

local SpriteDisplayer = {}
SpriteDisplayer.__index = SpriteDisplayer

-- Internal state
SpriteDisplayer._subsystems = nil
SpriteDisplayer._initialized = false

-- Public API namespaces
SpriteDisplayer.Sprite = {}
SpriteDisplayer.Layout = {}
SpriteDisplayer.Particle = {}
SpriteDisplayer.Constants = {}

-- Constants
SpriteDisplayer.Constants.COLOR_MODE = {
    MULTIPLY = 0,
    ADDITIVE = 1,
    COLORIZE = 2
}

-- Old alignment constants for backward compatibility
SpriteDisplayer.Constants.ALIGNMENT = {
    TOP_LEFT = "top-left",
    TOP_CENTER = "top-center",
    TOP_RIGHT = "top-right",
    CENTER_LEFT = "center-left",
    CENTER = "center-center",
    CENTER_RIGHT = "center-right",
    BOTTOM_LEFT = "bottom-left",
    BOTTOM_CENTER = "bottom-center",
    BOTTOM_RIGHT = "bottom-right"
}

-- New alignment constants (main axis)
SpriteDisplayer.Constants.MAIN_AXIS = {
    START = "start",
    CENTER = "center", 
    END = "end",
    SPACE_BETWEEN = "space_between",
    SPACE_AROUND = "space_around",
    SPACE_EVENLY = "space_evenly"
}

-- New alignment constants (cross axis)
SpriteDisplayer.Constants.CROSS_AXIS = {
    START = "start",
    CENTER = "center",
    END = "end",
    STRETCH = "stretch"
}

-- Initialization
function SpriteDisplayer:init()
    if self._initialized then
        print("WARNING: SpriteDisplayer already initialized")
        return self
    end
    
    print("Initializing SpriteDisplayer...")
    
    local success, err = pcall(function()
        -- Load subsystems in dependency order
        self._subsystems = {
            SpriteManager = require("scripts/sprite-widget/subsystems/sprite-manager"),
            LayoutManager = require("scripts/sprite-widget/subsystems/layout-manager"),
            ParticleSystem = require("scripts/sprite-widget/subsystems/particle-system"),
        }
        
        -- Initialize subsystems
        for name, subsystem in pairs(self._subsystems) do
            if subsystem.init then
                print("Initializing subsystem:", name)
                local sub_success, sub_err = pcall(function()
                    subsystem:init()
                end)
                
                if not sub_success then
                    print("WARNING: Failed to initialize subsystem", name, ":", sub_err)
                end
            end
        end
    end)
    
    if not success then
        print("ERROR: Failed to initialize SpriteDisplayer:", err)
        return nil
    end
    
    -- Set up public API wrappers
    self:_setupSpriteAPI()
    self:_setupLayoutAPI()
    self:_setupParticleAPI()
    self:_setupEventListeners()
    
    self._initialized = true
    print("SpriteDisplayer initialized successfully")
    
    return self
end

-- Internal helper: validate subsystems
function SpriteDisplayer:_getSubsystem(name, method)
    if not self._subsystems then
        print("ERROR: SpriteDisplayer not initialized")
        return nil
    end
    
    local subsystem = self._subsystems[name]
    if not subsystem then
        print("ERROR: Missing subsystem:", name)
        return nil
    end
    
    if method and not subsystem[method] then
        print("ERROR: Missing method:", method, "in subsystem:", name)
        return nil
    end
    
    return subsystem
end

-- Event listeners setup
function SpriteDisplayer:_setupEventListeners()
    Net:on("player_join", function(event)
        if event.player_id then
            print("SpriteDisplayer: Setting up player", event.player_id)
            local manager = self:_getSubsystem("SpriteManager", "setupPlayer")
            if manager then
                manager:setupPlayer(event.player_id)
            end
        end
    end)
    
    Net:on("player_disconnect", function(event)
        if event.player_id then
            print("SpriteDisplayer: Cleaning up player", event.player_id)
            local manager = self:_getSubsystem("SpriteManager", "cleanupPlayer")
            if manager then
                manager:cleanupPlayer(event.player_id)
            end
        end
    end)
    
    Net:on("tick", function(event)
        -- Tick-based updates if needed
    end)
end

-- Sprite API wrapper
function SpriteDisplayer:_setupSpriteAPI()
    local main = self
    
    -- Allocation
    self.Sprite.allocate = function(player_id, sprite_id, texture_path, anim_path, anim_state)
        if not player_id or not sprite_id or not texture_path then
            print("ERROR: player_id, sprite_id, and texture_path required")
            return false
        end
        
        local manager = main:_getSubsystem("SpriteManager", "allocate")
        if not manager then return false end
        
        return manager:allocate(player_id, sprite_id, texture_path, anim_path, anim_state)
    end
    
    -- Creation
    self.Sprite.create = function(player_id, sprite_id, obj_id, options)
        if not player_id or not sprite_id or not obj_id then
            print("ERROR: player_id, sprite_id, and obj_id required")
            return nil
        end
        
        local manager = main:_getSubsystem("SpriteManager", "create")
        if not manager then return nil end
        
        options = options or {}
        return manager:create(player_id, sprite_id, obj_id, options)
    end
    
    -- Instance management
    self.Sprite.get = function(player_id, obj_id)
        local manager = main:_getSubsystem("SpriteManager", "getInstance")
        if not manager then return nil end
        
        return manager:getInstance(player_id, obj_id)
    end
    
    self.Sprite.getAll = function(player_id)
        local manager = main:_getSubsystem("SpriteManager", "getAllInstances")
        if not manager then return {} end
        
        return manager:getAllInstances(player_id)
    end
    
    -- Removal
    self.Sprite.remove = function(player_id, obj_id)
        local manager = main:_getSubsystem("SpriteManager", "remove")
        if not manager then return nil end
        
        return manager:remove(player_id, obj_id)
    end
    
    self.Sprite.removeAll = function(player_id)
        local manager = main:_getSubsystem("SpriteManager", "removeAll")
        if not manager then return 0 end
        
        return manager:removeAll(player_id)
    end
    
    -- Deallocation
    self.Sprite.deallocate = function(player_id, sprite_id)
        local manager = main:_getSubsystem("SpriteManager", "deallocate")
        if not manager then return false end
        
        return manager:deallocate(player_id, sprite_id)
    end
    
    -- Batch operations
    self.Sprite.batchUpdate = function(player_id, update_table)
        local manager = main:_getSubsystem("SpriteManager", "batchUpdate")
        if not manager then return end
        
        manager:batchUpdate(player_id, update_table)
    end
    
    self.Sprite.groupOperation = function(player_id, obj_ids, operation, ...)
        local manager = main:_getSubsystem("SpriteManager", "groupOperation")
        if not manager then return {} end
        
        return manager:groupOperation(player_id, obj_ids, operation, ...)
    end
    
    -- Cleanup
    self.Sprite.cleanup = function(player_id)
        local manager = main:_getSubsystem("SpriteManager", "cleanup")
        if not manager then return false end
        
        return manager:cleanup(player_id)
    end
end

-- Layout API wrapper (enhanced with new alignment methods)
function SpriteDisplayer:_setupLayoutAPI()
    local main = self
    
    self.Layout.create = function(options)
        local manager = main:_getSubsystem("LayoutManager", "create")
        if not manager then return nil end
        
        return manager:create(options)
    end
    
    self.Layout.get = function(player_id, layout_id)
        local manager = main:_getSubsystem("LayoutManager", "get")
        if not manager then return nil end
        
        return manager:get(player_id, layout_id)
    end
    
    self.Layout.getAll = function(player_id)
        local manager = main:_getSubsystem("LayoutManager", "getAll")
        if not manager then return {} end
        
        return manager:getAll(player_id)
    end
    
    self.Layout.remove = function(player_id, layout_id)
        local manager = main:_getSubsystem("LayoutManager", "remove")
        if not manager then return false end
        
        return manager:remove(player_id, layout_id)
    end
    
    self.Layout.debug = function(player_id, layout_id)
        local manager = main:_getSubsystem("LayoutManager", "debug")
        if not manager then return end
        
        manager:debug(player_id, layout_id)
    end
    
    -- Helper method for creating layouts with proper alignment
    self.Layout.createRow = function(options)
        options = options or {}
        options.type = "horizontal"
        
        -- Convert old alignment to new if needed
        if options.alignment and options.alignment:find("^[a-z]+%-[a-z]+$") then
            -- Old format like "top-left"
            local vertical, horizontal = options.alignment:match("([a-z]+)%-([a-z]+)")
            if vertical == "top" then options.cross_axis_alignment = "start"
            elseif vertical == "center" then options.cross_axis_alignment = "center"
            elseif vertical == "bottom" then options.cross_axis_alignment = "end" end
            
            if horizontal == "left" then options.main_axis_alignment = "start"
            elseif horizontal == "center" then options.main_axis_alignment = "center"
            elseif horizontal == "right" then options.main_axis_alignment = "end" end
        end
        
        return main.Layout.create(options)
    end
    
    -- Helper method for creating layouts with proper alignment
    self.Layout.createColumn = function(options)
        options = options or {}
        options.type = "vertical"
        
        -- Convert old alignment to new if needed
        if options.alignment and options.alignment:find("^[a-z]+%-[a-z]+$") then
            -- Old format like "top-left"
            local vertical, horizontal = options.alignment:match("([a-z]+)%-([a-z]+)")
            if vertical == "top" then options.main_axis_alignment = "start"
            elseif vertical == "center" then options.main_axis_alignment = "center"
            elseif vertical == "bottom" then options.main_axis_alignment = "end" end
            
            if horizontal == "left" then options.cross_axis_alignment = "start"
            elseif horizontal == "center" then options.cross_axis_alignment = "center"
            elseif horizontal == "right" then options.cross_axis_alignment = "end" end
        end
        
        return main.Layout.create(options)
    end
end

-- Particle API wrapper
function SpriteDisplayer:_setupParticleAPI()
    local main = self
    
    self.Particle.createEffect = function(player_id, sprite_id, count, area, options)
        if not player_id or not sprite_id or not count or not area then
            print("ERROR: player_id, sprite_id, count, and area required")
            return {}
        end
        
        local system = main:_getSubsystem("ParticleSystem", "createEffect")
        if not system then return {} end
        
        options = options or {}
        return system:createEffect(player_id, sprite_id, count, area, options)
    end
    
    self.Particle.createGroup = function(player_id, sprite_id, positions, options)
        if not player_id or not sprite_id or not positions then
            print("ERROR: player_id, sprite_id, and positions required")
            return {}
        end
        
        local system = main:_getSubsystem("ParticleSystem", "createGroup")
        if not system then return {} end
        
        options = options or {}
        return system:createGroup(player_id, sprite_id, positions, options)
    end
end

-- Utility functions
SpriteDisplayer.transform_coordinate = function(value)
    return (value or 0) * 2  -- Transform position: 240x160 → 480x320
end

SpriteDisplayer.untransform_coordinate = function(value)
    return (value or 0) / 2  -- Untransform position: 480x320 → 240x160
end

-- Validation
function SpriteDisplayer:isValid()
    return self._initialized and self._subsystems ~= nil
end

-- Singleton instance
local instance = setmetatable({}, SpriteDisplayer)
instance:init()
return instance