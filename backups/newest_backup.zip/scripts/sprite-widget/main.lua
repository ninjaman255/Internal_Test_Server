-- sprite-widget/main.lua
-- Entry point following Displayer architecture

-- This file is now just a thin wrapper that returns the initialized SpriteDisplayer
local SpriteDisplayer = require("scripts/sprite-widget/sprite-displayer")

-- Event system integration example
Net:on("sprite_drawn", function(event)
    -- Example: Log sprite drawing for debugging
    print(string.format("[Event] Sprite drawn: Player=%s, Sprite=%s, Obj=%s",
        event.player_id, event.sprite_id, event.obj_id))
end)

Net:on("sprite_created", function(event)
    -- Example: Update UI counters when sprites are created
    print(string.format("[Event] Sprite created: Player=%s, Sprite=%s, Obj=%s",
        event.player_id, event.sprite_id, event.obj_id))
end)

-- Export the Displayer instance
return SpriteDisplayer