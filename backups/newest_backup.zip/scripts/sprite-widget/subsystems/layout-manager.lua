-- sprite-widget/subsystems/layout-manager.lua (updated debug function)
-- Layout management subsystem

local LayoutManager = {}
LayoutManager.__index = LayoutManager

-- Local requires
local Layout = require("scripts/sprite-widget/subsystems/layout")

function LayoutManager:init()
    self._layout_registry = {}   -- player_id -> {layout_id -> Layout}
    print("LayoutManager initialized")
    return self
end

-- Layout creation
function LayoutManager:create(options)
    options = options or {}
    
    local layout = Layout.new(options)
    
    -- Register if player_id provided
    if options.player_id then
        if not self._layout_registry[options.player_id] then
            self._layout_registry[options.player_id] = {}
        end
        self._layout_registry[options.player_id][layout._id] = layout
    end
    
    -- Emit creation event
    if options.player_id then
        Net:emit("layout_created", options.player_id, {
            player_id = options.player_id,
            layout_id = layout._id,
            type = layout.type,
            timestamp = os.time()
        })
    end
    
    return layout
end

-- Layout retrieval
function LayoutManager:get(player_id, layout_id)
    if self._layout_registry[player_id] then
        return self._layout_registry[player_id][layout_id]
    end
    return nil
end

function LayoutManager:getAll(player_id)
    return self._layout_registry[player_id] or {}
end

-- Layout removal
function LayoutManager:remove(player_id, layout_id)
    if not self._layout_registry[player_id] then
        return false
    end
    
    local layout = self._layout_registry[player_id][layout_id]
    if layout then
        layout:clear()
        self._layout_registry[player_id][layout_id] = nil
        
        -- Emit removal event
        Net:emit("layout_removed", player_id, {
            player_id = player_id,
            layout_id = layout_id,
            timestamp = os.time()
        })
        
        return true
    end
    
    return false
end

-- Debug utility (FIXED: Use %f for floating point numbers)
function LayoutManager:debug(player_id, layout_id)
    local layout = self:get(player_id, layout_id)
    if not layout then
        print("Layout not found:", layout_id)
        return
    end
    
    print("=== Layout Debug ===")
    print("Layout ID:", layout_id)
    print("Type:", layout.type)
    print("Position (logical 240x160):", layout.x, layout.y)
    print("Spacing (logical):", layout.spacing.x, layout.spacing.y)
    print("Alignment:", layout.alignment)
    print("Main Axis Alignment:", layout.main_axis_alignment)
    print("Cross Axis Alignment:", layout.cross_axis_alignment)
    print("Children:", #layout.children)
    print("---")
    
    for i, child in ipairs(layout.children) do
        local logical_x, logical_y = child:get_position()
        local display_x, display_y = child:get_raw_position()
        local width, height = child:get_scaled_width(), child:get_scaled_height()
        local base_width, base_height = child:get_base_width(), child:get_base_height()
        local sx, sy = child:get_scale()
        
        print(string.format("  Child %d: ID=%s", i, child._obj_id or "unknown"))
        print(string.format("    Logical Position (240x160): (%f, %f)", logical_x, logical_y))
        print(string.format("    Display Position (480x320): (%f, %f)", display_x, display_y))
        print(string.format("    Scaled Size (logical): (%f, %f)", width, height))
        print(string.format("    Base Size (logical): (%f, %f)", base_width, base_height))
        print(string.format("    Scale: (%f, %f)", sx, sy))
        print(string.format("    Display Scaled Size (for draw): (%f, %f)", width, height))
        if child.layout_parent then
            print("    Has layout parent: Yes")
        end
    end
    print("=================")
end

-- Cleanup
function LayoutManager:cleanupPlayer(player_id)
    if self._layout_registry[player_id] then
        for layout_id, layout in pairs(self._layout_registry[player_id]) do
            layout:clear()
        end
        self._layout_registry[player_id] = nil
    end
    return true
end

-- Singleton instance
local instance = setmetatable({}, LayoutManager)
instance:init()
return instance