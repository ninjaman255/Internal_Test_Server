-- sprite-widget/subsystems/particle-system.lua
-- Particle effects subsystem

local ParticleSystem = {}
ParticleSystem.__index = ParticleSystem

function ParticleSystem:init()
    self._active_effects = {}  -- player_id -> {effect_id -> particles}
    print("ParticleSystem initialized")
    return self
end

-- Particle effect creation
function ParticleSystem:createEffect(player_id, sprite_id, count, area, options)
    options = options or {}
    
    local particles = {}
    
    -- Validate area
    area = area or {x1 = 0, y1 = 0, x2 = 800, y2 = 600}
    
    -- Get sprite system
    local spriteSystem = require("scripts/sprite-widget/sprite-displayer")
    
    for i = 1, count do
        local obj_id = options.prefix or ("particle_" .. tostring(i))
        
        -- Random position within area
        local x = math.random(area.x1 or 0, area.x2 or 800)
        local y = math.random(area.y1 or 0, area.y2 or 600)
        
        -- Create particle sprite
        local particle = spriteSystem.Sprite.create(player_id, sprite_id, obj_id, {
            x = x,
            y = y,
            sx = options.sx or 1,
            sy = options.sy or 1,
            opacity = options.opacity or math.random(100, 255),
            r = options.r,
            g = options.g,
            b = options.b,
            a = options.a,
            anim_state = options.anim_state,
            width = options.width,
            height = options.height
        })
        
        if particle then
            table.insert(particles, particle)
            
            -- Apply additional particle properties
            if options.lifetime then
                self:_scheduleRemoval(player_id, obj_id, options.lifetime)
            end
        end
    end
    
    -- Register effect
    local effect_id = options.effect_id or ("effect_" .. tostring(math.random(1000, 9999)))
    if not self._active_effects[player_id] then
        self._active_effects[player_id] = {}
    end
    self._active_effects[player_id][effect_id] = particles
    
    -- Emit creation event
    Net:emit("particle_effect_created", player_id, {
        player_id = player_id,
        effect_id = effect_id,
        sprite_id = sprite_id,
        count = count,
        timestamp = os.time()
    })
    
    return particles
end

-- Sprite group creation
function ParticleSystem:createGroup(player_id, sprite_id, positions, options)
    options = options or {}
    
    local group = {}
    
    -- Get sprite system
    local spriteSystem = require("scripts/sprite-widget/sprite-displayer")
    
    for i, pos in ipairs(positions) do
        local obj_id = options.prefix or ("sprite_" .. tostring(i))
        
        local sprite = spriteSystem.Sprite.create(player_id, sprite_id, obj_id, {
            x = pos.x,
            y = pos.y,
            z = pos.z or options.z or 0,
            sx = pos.sx or options.sx or 1,
            sy = pos.sy or options.sy or 1,
            opacity = pos.opacity or options.opacity or 255,
            a = pos.a or options.a or 255,
            anim_state = pos.anim_state or options.anim_state,
            width = pos.width or options.width or 64,
            height = pos.height or options.height or 64
        })
        
        if sprite then
            table.insert(group, sprite)
        end
    end
    
    -- Emit creation event
    Net:emit("sprite_group_created", player_id, {
        player_id = player_id,
        sprite_id = sprite_id,
        count = #group,
        timestamp = os.time()
    })
    
    return group
end

-- Scheduled removal helper
function ParticleSystem:_scheduleRemoval(player_id, obj_id, delay)
    -- This would integrate with a timer system
    -- For now, just a placeholder
    print(string.format("Scheduled removal: Player %s, Obj %s in %s seconds",
        player_id, obj_id, delay))
end

-- Cleanup
function ParticleSystem:cleanupPlayer(player_id)
    if self._active_effects[player_id] then
        for effect_id, particles in pairs(self._active_effects[player_id]) do
            for _, particle in ipairs(particles) do
                particle:remove()
            end
        end
        self._active_effects[player_id] = nil
    end
    return true
end

-- Singleton instance
local instance = setmetatable({}, ParticleSystem)
instance:init()
return instance