-- sprite-widget/subsystems/sprite-object.lua
-- Sprite object class

local SpriteObject = {}
SpriteObject.__index = SpriteObject

-- Transformation functions (for position only)
local function transform_coordinate(value)
    return (value or 0) * 2
end

local function untransform_coordinate(value)
    return (value or 0) / 2
end

-- Constructor
function SpriteObject.new(player_id, sprite_id, obj_id, options)
    options = options or {}
    
    local self = setmetatable({}, SpriteObject)
    
    self._player_id = player_id
    self._sprite_id = sprite_id
    self._obj_id = obj_id
    
    -- Base dimensions (stored without coordinate transformation)
    self._base_width = options.width or 64
    self._base_height = options.height or 64
    
    -- Transform only position coordinates for display (240x160 → 480x320)
    -- DO NOT transform width/height dimensions
    local transformed_x = transform_coordinate(options.x or 0)
    local transformed_y = transform_coordinate(options.y or 0)
    
    -- Object properties
    self._obj = {
        id = obj_id,
        x = transformed_x,
        y = transformed_y,
        z = options.z or 0,
        sx = options.sx or 1.0,  -- Scale X (applied to base dimensions)
        sy = options.sy or 1.0,  -- Scale Y (applied to base dimensions)
        ro = options.ro or 0,
        opacity = options.opacity or 255,
        r = options.r or 255,
        g = options.g or 255,
        b = options.b or 255,
        a = options.a or 255,
        color_mode = options.color_mode or 0,
        anim_state = options.anim_state,
        ox = options.ox or 0,
        oy = options.oy or 0,
        offset_x = options.offset_x,
        offset_y = options.offset_y
    }
    
    -- Parent/child relationships
    self.layout_parent = nil
    self.parent = nil
    self.children = {}
    self._cached_properties = {}
    
    return self
end

-- Dimension getters
function SpriteObject:get_scaled_width()
    -- Returns the scaled width (base * scale) without coordinate transformation
    return self._base_width * (self._obj.sx or 1)
end

function SpriteObject:get_scaled_height()
    -- Returns the scaled height (base * scale) without coordinate transformation
    return self._base_height * (self._obj.sy or 1)
end

function SpriteObject:get_base_width()
    return self._base_width
end

function SpriteObject:get_base_height()
    return self._base_height
end

-- Dimension setters
function SpriteObject:set_base_width(width)
    self._base_width = width
    if self.layout_parent then
        self.layout_parent:_markDirty()
    end
    return self
end

function SpriteObject:set_base_height(height)
    self._base_height = height
    if self.layout_parent then
        self.layout_parent:_markDirty()
    end
    return self
end

function SpriteObject:set_base_size(width, height)
    self._base_width = width
    self._base_height = height
    if self.layout_parent then
        self.layout_parent:_markDirty()
    end
    return self
end

-- Drawing
function SpriteObject:draw()
    if not self._player_id or not self._sprite_id then
        print("ERROR: Cannot draw sprite without player_id or sprite_id")
        return self
    end
    
    -- Debug output
    print(string.format("Drawing sprite - Player: %s, Sprite: %s, Obj: %s, X: %s, Y: %s",
        self._player_id, self._sprite_id, self._obj_id,
        self._obj.x, self._obj.y))
    
    -- Network call with display coordinates
    Net.player_draw_sprite(self._player_id, self._sprite_id, self._obj)
    
    -- Emit draw event
    Net:emit("sprite_drawn",{
        player_id = self._player_id,
        sprite_id = self._sprite_id,
        obj_id = self._obj_id,
        position = {x = self._obj.x, y = self._obj.y},
        timestamp = os.time()
    })
    
    return self
end

-- Position management
function SpriteObject:set_position(x, y)
    -- Transform logical coordinates to display coordinates (240x160 → 480x320)
    local transformed_x = transform_coordinate(x)
    local transformed_y = transform_coordinate(y)
    
    self._obj.x = transformed_x
    self._obj.y = transformed_y
    
    self:_updateChildrenPosition()
    
    if self.layout_parent then
        self.layout_parent:_markDirty()
    end
    
    self:draw()
    return self
end

function SpriteObject:set_raw_position(x, y)
    -- Assume x, y are already in display coordinates (480x320)
    self._obj.x = x
    self._obj.y = y
    
    self:_updateChildrenPosition()
    
    if self.layout_parent then
        self.layout_parent:_markDirty()
    end
    
    return self
end

function SpriteObject:get_position()
    -- Return logical coordinates (240x160) by untransforming
    return untransform_coordinate(self._obj.x), untransform_coordinate(self._obj.y)
end

function SpriteObject:get_raw_position()
    -- Return display coordinates (480x320)
    return self._obj.x, self._obj.y
end

-- Transformation
function SpriteObject:set_scale(sx, sy)
    if sx then self._obj.sx = sx end
    if sy then self._obj.sy = sy end
    
    if self.layout_parent then
        self.layout_parent:_markDirty()
    end
    
    self:_updateChildrenPosition()
    self:draw()
    
    return self
end

function SpriteObject:set_scale_x(sx)
    return self:set_scale(sx, nil)
end

function SpriteObject:set_scale_y(sy)
    return self:set_scale(nil, sy)
end

function SpriteObject:get_scale()
    return self._obj.sx, self._obj.sy
end

function SpriteObject:set_rotation(degrees)
    self._obj.ro = degrees
    self:draw()
    return self
end

-- Appearance
function SpriteObject:set_opacity(alpha)
    self._obj.opacity = alpha
    self:draw()
    return self
end

function SpriteObject:set_color(r, g, b, a)
    self._obj.r = r or self._obj.r
    self._obj.g = g or self._obj.g
    self._obj.b = b or self._obj.b
    self._obj.a = a or self._obj.a
    self:draw()
    return self
end

function SpriteObject:set_color_mode(mode)
    self._obj.color_mode = mode
    self:draw()
    return self
end

function SpriteObject:set_animation(state)
    self._obj.anim_state = state
    self:draw()
    return self
end

function SpriteObject:set_visible(visible)
    if visible then
        self:set_opacity(255)
    else
        self:set_opacity(0)
    end
    return self
end

-- Hierarchy management
function SpriteObject:add_child(sprite_obj)
    if not sprite_obj or not sprite_obj._obj_id then
        return self
    end
    
    table.insert(self.children, sprite_obj)
    sprite_obj.parent = self
    
    local parent_x, parent_y = self:get_raw_position()
    local child_x, child_y = sprite_obj:get_raw_position()
    
    sprite_obj._obj.offset_x = (child_x - parent_x)
    sprite_obj._obj.offset_y = (child_y - parent_y)
    
    return self
end

function SpriteObject:remove_child(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            table.remove(self.children, i)
            child.parent = nil
            return self
        end
    end
    return self
end

function SpriteObject:_updateChildrenPosition()
    if #self.children == 0 then return end
    
    local parent_x, parent_y = self:get_raw_position()
    
    for _, child in ipairs(self.children) do
        if child._obj.offset_x and child._obj.offset_y then
            child:set_raw_position(
                parent_x + child._obj.offset_x,
                parent_y + child._obj.offset_y
            )
        end
    end
end

-- Property caching
function SpriteObject:cache_properties(key, properties)
    self._cached_properties[key] = properties
    return self
end

function SpriteObject:restore_properties(key)
    local props = self._cached_properties[key]
    if props then
        for k, v in pairs(props) do
            self._obj[k] = v
        end
        self:draw()
    end
    return self
end

-- Removal
function SpriteObject:remove()
    -- Remove from network
    Net.player_erase_sprite(self._player_id, self._obj_id)
    
    -- Remove from parent layouts
    if self.layout_parent then
        self.layout_parent:remove_child(self)
    end
    
    -- Remove from parent sprite
    if self.parent then
        self.parent:remove_child(self)
    end
    
    -- Remove children
    for _, child in ipairs(self.children) do
        child:remove()
    end
    self.children = {}
    
    -- Emit removal event
    Net:emit("sprite_removed", {
        player_id = self._player_id,
        obj_id = self._obj_id,
        timestamp = os.time()
    })
    
    return nil
end

return SpriteObject