-- sprite-widget/subsystems/layout.lua
-- Layout class

local Layout = {}
Layout.__index = Layout

-- Alignment parsing
local function parse_alignment(alignment)
    if not alignment then
        return "start", "start", "new"
    end
    
    -- Check for old format (top-left, center-center, etc.)
    if alignment:find("^[a-z]+%-[a-z]+$") then
        local parts = {}
        for part in alignment:gmatch("[^%-]+") do
            table.insert(parts, part:lower())
        end
        
        if #parts >= 2 then
            return parts[1], parts[2], "old"
        end
    end
    
    -- Check for new format (start-center, etc.)
    if alignment:find("^[%-%w_]+%-[%-%w_]+$") then
        local parts = {}
        for part in alignment:gmatch("[^%-]+") do
            table.insert(parts, part:lower())
        end
        
        if #parts >= 2 then
            return parts[1], parts[2], "new"
        end
    end
    
    -- Single value - use for both axes
    return alignment:lower(), alignment:lower(), "new"
end

-- Constructor
function Layout.new(options)
    options = options or {}
    
    local self = setmetatable({}, Layout)
    
    self.type = options.type or "absolute"
    self.x = options.x or 0  -- Logical coordinates (240x160 space)
    self.y = options.y or 0  -- Logical coordinates (240x160 space)
    self.z = options.z or 0
    self.spacing = options.spacing or { x = 0, y = 0 }  -- Logical spacing
    self.max_children = options.max_children or math.huge
    
    -- Parse alignment
    local alignment = options.alignment or "start-start"
    local main_axis, cross_axis, format = parse_alignment(alignment)
    
    if format == "old" then
        -- Convert old format to new format
        -- For backward compatibility
        self.alignment = alignment  -- Store original
        if self.type == "horizontal" then
            -- old vertical -> new cross axis
            -- old horizontal -> new main axis
            if main_axis == "top" then self.cross_axis_alignment = "start"
            elseif main_axis == "center" then self.cross_axis_alignment = "center"
            elseif main_axis == "bottom" then self.cross_axis_alignment = "end" end
            
            if cross_axis == "left" then self.main_axis_alignment = "start"
            elseif cross_axis == "center" then self.main_axis_alignment = "center"
            elseif cross_axis == "right" then self.main_axis_alignment = "end" end
        elseif self.type == "vertical" then
            -- old vertical -> new main axis
            -- old horizontal -> new cross axis
            if main_axis == "top" then self.main_axis_alignment = "start"
            elseif main_axis == "center" then self.main_axis_alignment = "center"
            elseif main_axis == "bottom" then self.main_axis_alignment = "end" end
            
            if cross_axis == "left" then self.cross_axis_alignment = "start"
            elseif cross_axis == "center" then self.cross_axis_alignment = "center"
            elseif cross_axis == "right" then self.cross_axis_alignment = "end" end
        else
            self.main_axis_alignment = "start"
            self.cross_axis_alignment = "start"
        end
    else
        self.alignment = alignment
        self.main_axis_alignment = options.main_axis_alignment or main_axis
        self.cross_axis_alignment = options.cross_axis_alignment or cross_axis
    end
    
    self.children = {}
    self.parent = nil
    self._dirty = false
    self._id = options.id or tostring(math.random(100000, 999999))
    self._player_id = options.player_id
    
    return self
end

-- Dirty state management
function Layout:_markDirty()
    self._dirty = true
end

-- Child management
function Layout:add_child(sprite_obj)
    if #self.children >= self.max_children then
        print("WARNING: Layout max children reached")
        return false
    end
    
    table.insert(self.children, sprite_obj)
    sprite_obj.layout_parent = self
    self._dirty = true
    
    self:_update_children()
    return true
end

function Layout:remove_child(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            table.remove(self.children, i)
            child.layout_parent = nil
            self._dirty = true
            return true
        end
    end
    return false
end

function Layout:clear()
    for _, child in ipairs(self.children) do
        child.layout_parent = nil
    end
    self.children = {}
    self._dirty = true
end

-- Layout properties
function Layout:set_position(x, y)
    self.x = x
    self.y = y
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_alignment(alignment)
    self.alignment = alignment
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_main_axis_alignment(alignment)
    self.main_axis_alignment = alignment
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_cross_axis_alignment(alignment)
    self.cross_axis_alignment = alignment
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_spacing(x, y)
    self.spacing.x = x or self.spacing.x
    self.spacing.y = y or self.spacing.y
    self._dirty = true
    self:_update_children()
    return self
end

-- Child ordering
function Layout:swap_children(index1, index2)
    if index1 >= 1 and index1 <= #self.children and
       index2 >= 1 and index2 <= #self.children then
        self.children[index1], self.children[index2] = 
            self.children[index2], self.children[index1]
        self._dirty = true
        self:_update_children()
        return true
    end
    return false
end

function Layout:bring_child_to_front(sprite_obj)
    local index = self:get_child_index(sprite_obj)
    if index > 0 then
        return self:move_child(index, #self.children)
    end
    return false
end

function Layout:send_child_to_back(sprite_obj)
    local index = self:get_child_index(sprite_obj)
    if index > 0 then
        return self:move_child(index, 1)
    end
    return false
end

-- Query methods
function Layout:get_child_count()
    return #self.children
end

function Layout:get_child_at(index)
    return self.children[index]
end

function Layout:get_child_index(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            return i
        end
    end
    return -1
end

-- Fixed distribution function
function Layout:_distribute_children(child_count, total_size, spacing, alignment)
    local start_pos = 0
    local effective_spacing = spacing
    
    if alignment == "center" then
        -- Center the group
        start_pos = -total_size / 2
    elseif alignment == "end" then
        -- Align to end
        start_pos = -total_size
    elseif alignment == "space_between" and child_count > 1 then
        -- Distribute space between children
        local space = -total_size  -- Negative because we're positioning from end
        effective_spacing = space / (child_count - 1)
        start_pos = 0
    elseif alignment == "space_around" then
        -- Distribute space around children
        local space = -total_size
        effective_spacing = space / child_count
        start_pos = effective_spacing / 2
    elseif alignment == "space_evenly" then
        -- Distribute space evenly
        local space = -total_size
        effective_spacing = space / (child_count + 1)
        start_pos = effective_spacing
    -- else "start" - default, no adjustment
    end
    
    return start_pos, effective_spacing
end

-- Update children positions
function Layout:_update_children()
    if not self._dirty or #self.children == 0 then return end
    
    if self.type == "horizontal" then
        self:_arrange_horizontal(self.x, self.y, 
                                self.spacing.x, self.spacing.y)
    elseif self.type == "vertical" then
        self:_arrange_vertical(self.x, self.y,
                              self.spacing.x, self.spacing.y)
    elseif self.type == "grid" then
        self:_arrange_grid(self.x, self.y,
                          self.spacing.x, self.spacing.y)
    elseif self.type == "relative" then
        self:_arrange_relative(self.x, self.y)
    elseif self.type == "absolute" then
        self:_arrange_absolute(self.x, self.y)
    end
    
    self._dirty = false
end

-- Layout arrangement methods
function Layout:_arrange_horizontal(x, y, spacing_x, spacing_y)
    local total_width = 0
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64
        total_width = total_width + child_width + spacing_x
    end
    
    if #self.children > 0 then
        total_width = total_width - spacing_x
    end
    
    -- Calculate distribution for main axis (horizontal)
    local start_x, effective_spacing = self:_distribute_children(
        #self.children, total_width, spacing_x, self.main_axis_alignment
    )
    
    local current_x = x + start_x
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64
        local child_height = child:get_scaled_height() or 64
        
        -- Calculate Y position based on cross axis alignment
        local child_y = y
        if self.cross_axis_alignment == "center" then
            child_y = y - (child_height / 2)
        elseif self.cross_axis_alignment == "end" then
            child_y = y - child_height
        end
        
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(current_x), transform(child_y))
        current_x = current_x + child_width + effective_spacing
    end
end

function Layout:_arrange_vertical(x, y, spacing_x, spacing_y)
    local total_height = 0
    for _, child in ipairs(self.children) do
        local child_height = child:get_scaled_height() or 64
        total_height = total_height + child_height + spacing_y
    end
    
    if #self.children > 0 then
        total_height = total_height - spacing_y
    end
    
    -- Calculate distribution for main axis (vertical)
    local start_y, effective_spacing = self:_distribute_children(
        #self.children, total_height, spacing_y, self.main_axis_alignment
    )
    
    local current_y = y + start_y
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64
        local child_height = child:get_scaled_height() or 64
        
        -- Calculate X position based on cross axis alignment
        local child_x = x
        if self.cross_axis_alignment == "center" then
            child_x = x - (child_width / 2)
        elseif self.cross_axis_alignment == "end" then
            child_x = x - child_width
        end
        
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(child_x), transform(current_y))
        current_y = current_y + child_height + effective_spacing
    end
end

function Layout:_arrange_grid(x, y, spacing_x, spacing_y)
    if #self.children == 0 then return end
    
    -- Calculate grid dimensions
    local grid_cols = math.ceil(math.sqrt(#self.children))
    if grid_cols == 0 then grid_cols = 1 end
    
    local grid_rows = math.ceil(#self.children / grid_cols)
    
    -- Find max child dimensions
    local max_child_width = 0
    local max_child_height = 0
    for _, child in ipairs(self.children) do
        local child_width = child:get_scaled_width() or 64
        local child_height = child:get_scaled_height() or 64
        max_child_width = math.max(max_child_width, child_width)
        max_child_height = math.max(max_child_height, child_height)
    end
    
    -- Calculate total dimensions
    local total_width = (max_child_width * grid_cols) + (spacing_x * (grid_cols - 1))
    local total_height = (max_child_height * grid_rows) + (spacing_y * (grid_rows - 1))
    
    -- Calculate alignment offsets
    local offset_x, offset_y = 0, 0
    
    if self.main_axis_alignment == "center" or self.cross_axis_alignment == "center" then
        offset_x = -total_width / 2
        offset_y = -total_height / 2
    elseif self.main_axis_alignment == "end" or self.cross_axis_alignment == "end" then
        offset_x = -total_width
        offset_y = -total_height
    end
    
    -- Position children
    for i, child in ipairs(self.children) do
        local row = math.floor((i - 1) / grid_cols)
        local col = (i - 1) % grid_cols
        
        local child_x = x + offset_x + 
                       (col * (max_child_width + spacing_x))
        local child_y = y + offset_y + 
                       (row * (max_child_height + spacing_y))
        
        -- Transform logical coordinates to display coordinates
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(child_x), transform(child_y))
    end
end

function Layout:_arrange_relative(x, y)
    for _, child in ipairs(self.children) do
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(
            transform(x + (child._obj.offset_x or 0)),
            transform(y + (child._obj.offset_y or 0))
        )
    end
end

function Layout:_arrange_absolute(x, y)
    for _, child in ipairs(self.children) do
        local transform = require("scripts/sprite-widget/sprite-displayer").transform_coordinate
        child:set_raw_position(transform(x), transform(y))
    end
end

-- Move child (helper for bring_to_front/send_to_back)
function Layout:move_child(from_index, to_index)
    if from_index >= 1 and from_index <= #self.children and
       to_index >= 1 and to_index <= #self.children then
        local child = table.remove(self.children, from_index)
        table.insert(self.children, to_index, child)
        self._dirty = true
        self:_update_children()
        return true
    end
    return false
end

-- Add child at index
function Layout:add_child_at(sprite_obj, index)
    if #self.children >= self.max_children then
        return false
    end
    
    index = math.min(math.max(1, index), #self.children + 1)
    table.insert(self.children, index, sprite_obj)
    sprite_obj.layout_parent = self
    self._dirty = true
    self:_update_children()
    return true
end

-- Remove child at index
function Layout:remove_child_at(index)
    if index >= 1 and index <= #self.children then
        local child = self.children[index]
        child.layout_parent = nil
        table.remove(self.children, index)
        self._dirty = true
        return child
    end
    return nil
end

return Layout