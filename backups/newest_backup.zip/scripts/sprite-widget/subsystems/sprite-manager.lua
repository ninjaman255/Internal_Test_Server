-- sprite-widget/subsystems/sprite-manager.lua
-- Sprite lifecycle and state management

local SpriteManager = {}
SpriteManager.__index = SpriteManager

-- Local requires
local SpriteObject = require("scripts/sprite-widget/subsystems/sprite-object")

function SpriteManager:init()
    self._sprite_cache = {}      -- player_id -> {sprite_id -> true}
    self._instance_registry = {} -- player_id -> {obj_id -> SpriteObject}
    self._player_data = {}       -- player_id -> {resources, next_id, etc.}
    
    print("SpriteManager initialized")
    return self
end

-- Player management
function SpriteManager:setupPlayer(player_id)
    if not player_id then return end
    
    if not self._sprite_cache[player_id] then
        self._sprite_cache[player_id] = {}
    end
    
    if not self._instance_registry[player_id] then
        self._instance_registry[player_id] = {}
    end
    
    if not self._player_data[player_id] then
        self._player_data[player_id] = {
            next_obj_id = 10000,
            resources = {}
        }
    end
    
    -- Emit event for other systems
    Net:emit("sprite_player_ready", {
        player_id = player_id,
        timestamp = os.time()
    })
end

function SpriteManager:cleanupPlayer(player_id)
    if not player_id then return end
    
    -- Remove all instances
    self:removeAll(player_id)
    
    -- Deallocate all sprites
    if self._sprite_cache[player_id] then
        for sprite_id, _ in pairs(self._sprite_cache[player_id]) do
            self:deallocate(player_id, sprite_id)
        end
        self._sprite_cache[player_id] = nil
    end
    
    self._instance_registry[player_id] = nil
    self._player_data[player_id] = nil
    
    -- Emit cleanup event
    Net:emit("sprite_player_cleaned", {
        player_id = player_id,
        timestamp = os.time()
    })
end

-- Resource allocation
function SpriteManager:allocate(player_id, sprite_id, texture_path, anim_path, anim_state)
    if not player_id or not sprite_id or not texture_path then
        print("ERROR: Invalid allocation parameters")
        return false
    end
    
    -- Setup player if not exists
    self:setupPlayer(player_id)
    
    if self._sprite_cache[player_id][sprite_id] then
        return true -- Already allocated
    end
    
    local fields = {
        texture_path = texture_path
    }
    
    if anim_path then
        fields.anim_path = anim_path
        fields.anim_state = anim_state or ""
    end
    
    -- Network calls
    Net.player_alloc_sprite(player_id, sprite_id, fields)
    Net.provide_asset_for_player(player_id, texture_path)
    
    if anim_path then
        Net.provide_asset_for_player(player_id, anim_path)
    end
    
    self._sprite_cache[player_id][sprite_id] = true
    
    -- Emit allocation event
    Net:emit("sprite_allocated",{
        player_id = player_id,
        sprite_id = sprite_id,
        texture_path = texture_path,
        timestamp = os.time()
    })
    
    return true
end

-- Sprite creation
function SpriteManager:create(player_id, sprite_id, obj_id, options)
    options = options or {}
    
    -- Validate allocation
    if not self._sprite_cache[player_id] or not self._sprite_cache[player_id][sprite_id] then
        print("ERROR: Sprite not allocated")
        return nil
    end
    
    -- Ensure scale is explicitly set if not provided
    if options.sx == nil then
        options.sx = 2.0  -- Default scale for sprites
    end
    if options.sy == nil then
        options.sy = 2.0  -- Default scale for sprites
    end
    
    -- Create sprite object
    local sprite_obj = SpriteObject.new(player_id, sprite_id, obj_id, options)
    
    -- Register instance
    if not self._instance_registry[player_id] then
        self._instance_registry[player_id] = {}
    end
    self._instance_registry[player_id][obj_id] = sprite_obj
    
    -- Update player data
    if self._player_data[player_id] then
        self._player_data[player_id].next_obj_id = math.max(
            self._player_data[player_id].next_obj_id,
            tonumber(obj_id) or 0
        ) + 1
    end
    
    -- Draw initial state
    sprite_obj:draw()
    
    -- Emit creation event
    Net:emit("sprite_created", {
        player_id = player_id,
        sprite_id = sprite_id,
        obj_id = obj_id,
        timestamp = os.time()
    })
    
    return sprite_obj
end

-- Instance management
function SpriteManager:getInstance(player_id, obj_id)
    if self._instance_registry[player_id] then
        return self._instance_registry[player_id][obj_id]
    end
    return nil
end

function SpriteManager:getAllInstances(player_id)
    return self._instance_registry[player_id] or {}
end

-- Removal operations
function SpriteManager:remove(player_id, obj_id)
    local instance = self:getInstance(player_id, obj_id)
    if instance then
        return instance:remove()
    end
    return nil
end

function SpriteManager:removeAll(player_id)
    if not self._instance_registry[player_id] then
        return 0
    end
    
    local count = 0
    for obj_id, instance in pairs(self._instance_registry[player_id]) do
        instance:remove()
        count = count + 1
    end
    
    self._instance_registry[player_id] = {}
    return count
end

-- Deallocation
function SpriteManager:deallocate(player_id, sprite_id)
    if not player_id or not sprite_id then
        return false
    end
    
    -- Remove all instances using this sprite
    if self._instance_registry[player_id] then
        local to_remove = {}
        for obj_id, instance in pairs(self._instance_registry[player_id]) do
            if instance._sprite_id == sprite_id then
                table.insert(to_remove, obj_id)
            end
        end
        
        for _, obj_id in ipairs(to_remove) do
            self._instance_registry[player_id][obj_id]:remove()
        end
    end
    
    -- Clear from cache
    if self._sprite_cache[player_id] then
        self._sprite_cache[player_id][sprite_id] = nil
    end
    
    -- Network call
    Net.player_dealloc_sprite(player_id, sprite_id)
    
    -- Emit deallocation event
    Net:emit("sprite_deallocated",{
        player_id = player_id,
        sprite_id = sprite_id,
        timestamp = os.time()
    })
    
    return true
end

-- Batch operations
function SpriteManager:batchUpdate(player_id, update_table)
    if not update_table then return end
    
    for obj_id, changes in pairs(update_table) do
        local instance = self:getInstance(player_id, obj_id)
        if instance then
            -- Apply changes
            for prop, value in pairs(changes) do
                if prop == "x" or prop == "y" then
                    instance:set_position(changes.x, changes.y)
                elseif prop == "sx" or prop == "sy" then
                    instance:set_scale(changes.sx, changes.sy)
                elseif prop == "opacity" then
                    instance:set_opacity(value)
                elseif prop == "anim_state" then
                    instance:set_animation(value)
                elseif prop == "width" then
                    instance:set_base_width(value)
                elseif prop == "height" then
                    instance:set_base_height(value)
                end
            end
            instance:draw()
        end
    end
end

function SpriteManager:groupOperation(player_id, obj_ids, operation, ...)
    local results = {}
    
    for _, obj_id in ipairs(obj_ids) do
        local instance = self:getInstance(player_id, obj_id)
        if instance then
            local success = self:_applyGroupOperation(instance, operation, ...)
            if success then
                table.insert(results, instance)
            end
        end
    end
    
    return results
end

function SpriteManager:_applyGroupOperation(instance, operation, ...)
    if operation == "remove" then
        instance:remove()
    elseif operation == "hide" then
        instance:set_visible(false)
    elseif operation == "show" then
        instance:set_visible(true)
    elseif operation == "set_position" then
        local x, y = ...
        instance:set_position(x, y)
    elseif operation == "set_opacity" then
        instance:set_opacity(...)
    elseif operation == "set_scale" then
        local sx, sy = ...
        instance:set_scale(sx, sy)
    end
    
    return true
end

-- Z-order management
function SpriteManager:reorderSprites(player_id, z_order_table)
    for obj_id, z_index in pairs(z_order_table) do
        local instance = self:getInstance(player_id, obj_id)
        if instance then
            instance._obj.z = z_index
            instance:draw()
        end
    end
end

-- Cleanup
function SpriteManager:cleanup(player_id)
    return self:cleanupPlayer(player_id)
end

-- Singleton instance
local instance = setmetatable({}, SpriteManager)
instance:init()
return instance