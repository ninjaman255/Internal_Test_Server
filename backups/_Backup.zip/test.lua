-- sprite_demo/main.lua
local SpriteSystem = require("scripts/widgets/main")

-- Store player states
local player_states = {}

-- Global constants for 240x160 screen bounds
local SCREEN_WIDTH = 240
local SCREEN_HEIGHT = 160
local SPRITE_WIDTH = 21
local SPRITE_HEIGHT = 39

-- Timer system
local Timer = {}
Timer.__index = Timer

function Timer.new(delay, callback)
    local self = setmetatable({}, Timer)
    self.delay = delay
    self.callback = callback
    self.elapsed = 0
    self.active = true
    return self
end

function Timer:update(dt)
    if not self.active then return false end

    self.elapsed = self.elapsed + dt
    if self.elapsed >= self.delay then
        self.active = false
        self.callback()
        return true
    end
    return false
end

-- Add a timer for a player
local function add_timer(player_state, delay, callback)
    table.insert(player_state.timers, Timer.new(delay, callback))
end

-- Add this to test.lua to debug grid visibility
local function debug_grid_visibility(player_id, layout_id)
    local layout = SpriteSystem.get_layout(player_id, layout_id)
    if not layout then return end
    
    print("=== GRID DEBUG ===")
    print("Layout position (original):", layout.x, layout.y)
    print("Layout position (transformed):", transform_coordinate(layout.x), transform_coordinate(layout.y))
    print("Screen bounds: 0-240, 0-160")
    
    for i, child in ipairs(layout.children) do
        local x, y = child:get_position()  -- Original coordinates
        local tx, ty = child:get_raw_position()  -- Transformed coordinates
        local w, h = child:get_base_width(), child:get_base_height()
        local sw, sh = child:get_scaled_width(), child:get_scaled_height()
        
        print(string.format("Child %d:", i))
        print("  Original pos: %.1f, %.1f", x, y)
        print("  Transformed pos: %.1f, %.1f", tx, ty)
        print("  Base size: %.1f × %.1f", w, h)
        print("  Scaled size: %.1f × %.1f", sw/2, sh/2)  -- Divide by 2 for original
        print("  On screen?: %s", 
              (x >= 0 and x + w <= SCREEN_WIDTH and y >= 0 and y + h <= SCREEN_HEIGHT) and "YES" or "NO")
    end
    print("==================")
end

-- Helper function to check if coordinates are on screen
local function is_on_screen(x, y, width, height)
    width = width or SPRITE_WIDTH
    height = height or SPRITE_HEIGHT
    return x >= 0 and x + width <= SCREEN_WIDTH and
        y >= 0 and y + height <= SCREEN_HEIGHT
end

-- Initialize sprite system for a player
local function init_player_sprites(player_id)
    print("Initializing sprites for player: " .. player_id)

    -- Allocate the card sprite
    SpriteSystem.allocate(player_id, "card",
        "/server/assets/card.png",
        "/server/assets/card.anim",
        "IDLE_D"
    )

    -- Initialize player state
    player_states[player_id] = {
        sprites = {},
        layouts = {},
        demo_phase = 1,
        last_tick = 0,
        timers = {}
    }

    local state = player_states[player_id]

    -- Phase 1: Basic sprite creation and properties
    print("Phase 1: Basic sprite creation")

    -- Create individual sprites with different properties
    state.sprites.sprite1 = SpriteSystem.create(player_id, "card", "demo_sprite1", {
        x = 20,
        y = 20,
        width = SPRITE_WIDTH,
        height = SPRITE_HEIGHT,
        anim_state = "IDLE_D",
        opacity = 255,
        r = 255,
        g = 200,
        b = 200
    })

    state.sprites.sprite2 = SpriteSystem.create(player_id, "card", "demo_sprite2", {
        x = 80,
        y = 20,
        width = SPRITE_WIDTH,
        height = SPRITE_HEIGHT,
        anim_state = "IDLE_D",
        r = 200,
        g = 255,
        b = 200,
        ro = 15
    })

    state.sprites.sprite3 = SpriteSystem.create(player_id, "card", "demo_sprite3", {
        x = 140,
        y = 20,
        width = SPRITE_WIDTH,
        height = SPRITE_HEIGHT,
        anim_state = "IDLE_D",
        opacity = 180,
        r = 200,
        g = 200,
        b = 255
    })

    -- Phase 2: Layout system demonstration
    print("Phase 2: Layout system")

    -- Create a horizontal layout
    state.layouts.horizontal = SpriteSystem.create_layout({
        player_id = player_id,
        id = "horizontal_layout",
        type = "horizontal",
        x = 30,
        y = 80,
        spacing = { x = 10, y = 0 },
        max_children = 5,
        alignment = "center"
    })

    -- Create sprites for horizontal layout
    for i = 1, 5 do
        local sprite = SpriteSystem.create(player_id, "card", "h_sprite" .. i, {
            width = SPRITE_WIDTH,
            height = SPRITE_HEIGHT,
            anim_state = "IDLE_D",
            opacity = 200,
            sx = 0.7 + (i * 0.1),
            sy = 0.7 + (i * 0.1)
        })
        state.layouts.horizontal:add_child(sprite)
    end

    -- Create a vertical layout
    state.layouts.vertical = SpriteSystem.create_layout({
        player_id = player_id,
        id = "vertical_layout",
        type = "vertical",
        width = SPRITE_WIDTH,
        height = SCREEN_HEIGHT,
        x = 180,
        y = 30,
        spacing = { x = 0, y = 5 },
        max_children = 4,
        alignment = "center-left"
    })

    state.layouts.vertical = SpriteSystem.create_layout({
        player_id = player_id,
        id = "vertical_layout2",
        type = "vertical",
        x = 0,
        y = 0,
        width = SPRITE_WIDTH,
        height = SCREEN_HEIGHT,
        spacing = { x = 0, y = 5 },
        max_children = 4,
        alignment = "center-center"
    })

    -- Create sprites for vertical layout
    for i = 1, 4 do
        local sprite = SpriteSystem.create(player_id, "card", "v_sprite2" .. i, {
            w = SPRITE_WIDTH,
            h = SPRITE_HEIGHT,
            anim_state = "IDLE_D",
            opacity = 255,
            r = 255,
            g = 200,
            b = 200
        })
        state.layouts.vertical:add_child(sprite)
    end



    -- Create sprites for vertical layout
    for i = 1, 4 do
        local sprite = SpriteSystem.create(player_id, "card", "v_sprite" .. i, {
            width = SPRITE_WIDTH,
            height = SPRITE_HEIGHT,
            anim_state = "IDLE_D",
            opacity = 150 + (i * 25),
            r = 255 - (i * 40),
            g = 200,
            b = 200
        })
        state.layouts.vertical:add_child(sprite)
    end

    -- Phase 3: Grid layout
      print("Phase 3: Grid")
    state.layouts.grid = SpriteSystem.create_layout({
        player_id = player_id,
        id = "grid_layout",
        type = "grid",
        width = 480,
        height =  320,
        x = 0,  -- Adjusted for better visibility
        y = 0, -- Adjusted for better visibility
        spacing = {  x = 10, y = 10 },  -- Increased spacing to account for sprite size
        max_children = 9,
        alignment = "top-left",  -- Changed from center-center for better control
    })

    for i = 1, 9 do
        local sprite = SpriteSystem.create(player_id, "card", "grid_sprite" .. i, {
            width = SPRITE_WIDTH,
            height = SPRITE_HEIGHT,
            anim_state = "IDLE_D",
            opacity = 170,
        })
        state.layouts.grid:add_child(sprite)
    end
    
    state.layouts.grid:_update_children()
    for _, child in ipairs(state.layouts.grid.children) do
        child:draw()
    end

    add_timer(state, 0.5, function()
        debug_grid_visibility(player_id, "grid_layout")
    end)
        -- After creating grid

    -- Phase 4: Parent-child relationships
    print("Phase 4: Parent-child relationships")

    state.sprites.parent = SpriteSystem.create(player_id, "card", "parent_sprite", {
        x = 200,
        y = 100,
        width = SPRITE_WIDTH,
        height = SPRITE_HEIGHT,
        anim_state = "IDLE_D",
        r = 255,
        g = 100,
        b = 100
    })

    state.sprites.child1 = SpriteSystem.create(player_id, "card", "child_sprite1", {
        x = 220,
        y = 110,
        width = SPRITE_WIDTH,
        height = SPRITE_HEIGHT,
        anim_state = "IDLE_D",
        sx = 0.6,
        sy = 0.6,
        r = 100,
        g = 255,
        b = 100
    })

    state.sprites.parent:add_child(state.sprites.child1)

    -- Phase 5: Particle effect (small, on-screen)
    print("Phase 5: Particle effect")

    --local particles = SpriteSystem.create_particle_effect(player_id, "card", 8, {
    --    x1 = 10,
    --    x2 = 50,
    --    y1 = 130,
    --    y2 = 150
    --}, {
    --    sx = 0.4,
    --    sy = 0.4,
    --    opacity = 120,
    --    r = 150,
    --    g = 150,
    --    b = 255
    --})
--
    -- Store particle references
    -- state.particles = particles

    print("Sprite demo initialized for player: " .. player_id)
end

-- Update timers for a player
local function update_timers(player_state, dt)
    if not player_state.timers or #player_state.timers == 0 then return end

    -- Update all timers
    for i = #player_state.timers, 1, -1 do
        local timer = player_state.timers[i]
        if timer:update(dt) then
            -- Remove completed timers
            table.remove(player_state.timers, i)
        end
    end
end


-- Fix the grid alignment indexing issue
local function get_next_alignment(time)
    local align_index = math.floor(time % 3) + 1 -- Gives 1, 2, 3
    local alignments = {
        SpriteSystem.ALIGNMENT.TOP_LEFT,
        SpriteSystem.ALIGNMENT.CENTER,
        SpriteSystem.ALIGNMENT.BOTTOM_RIGHT
    }
    return alignments[align_index] or SpriteSystem.ALIGNMENT.CENTER
end

-- Update function called every tick
local function update_player_sprites(player_id, dt)
    local state = player_states[player_id]
    if not state then return end

    -- Update timers first
    update_timers(state, dt)

    state.last_tick = state.last_tick + dt

    -- Animate sprites based on time
    local time = state.last_tick

    -- Phase 1: Animate individual sprites
    if state.sprites.sprite1 then
        -- Bounce effect
        local bounce_y = 20 + math.sin(time * 2) * 5
        state.sprites.sprite1:set_position(20, bounce_y)

        -- Rotate slowly
        state.sprites.sprite1:set_rotation(math.sin(time) * 10)

        -- Pulse opacity
        local pulse_opacity = 180 + math.sin(time * 3) * 75
        state.sprites.sprite1:set_opacity(pulse_opacity)
    end

    if state.sprites.sprite2 then
        -- Scale animation
        local scale = 1.2 + math.sin(time * 1.5) * 0.3
        state.sprites.sprite2:set_scale(scale, scale)

        -- Color cycle
        local r = 150 + math.sin(time * 0.5) * 105
        local g = 150 + math.sin(time * 0.7) * 105
        local b = 150 + math.sin(time * 0.9) * 105
        state.sprites.sprite2:set_color(r, g, b)
    end

    if state.sprites.sprite3 then
        -- Move in circle
        local radius = 15
        local circle_x = 140 + math.cos(time * 1.2) * radius
        local circle_y = 20 + math.sin(time * 1.2) * radius
        state.sprites.sprite3:set_position(circle_x, circle_y)
    end

    -- Phase 2: Animate layouts
    if state.layouts.horizontal then
        -- Move layout horizontally
        local layout_x = 30 + math.sin(time * 0.8) * 20
        state.layouts.horizontal:set_position(layout_x, 80)

        -- Change spacing
        local spacing_x = 10 + math.sin(time * 0.5) * 8
        state.layouts.horizontal:set_spacing(spacing_x, 0)
    end

    if state.layouts.vertical then
        -- Move layout vertically
        local layout_y = 30 + math.sin(time * 0.7) * 15
        state.layouts.vertical:set_position(180, layout_y)
    end

    if state.layouts.grid then
        -- Change grid alignment with fixed indexing
        local alignment = get_next_alignment(time * 0.5) -- Slower change
        state.layouts.grid:set_alignment(alignment)
    end

    -- Phase 4: Animate parent-child relationship
    if state.sprites.parent then
        -- Move parent in a small circle
        local parent_x = 200 + math.cos(time * 0.6) * 20
        local parent_y = 100 + math.sin(time * 0.6) * 10
        state.sprites.parent:set_position(parent_x, parent_y)

        -- Rotate parent
        state.sprites.parent:set_rotation(time * 20)
    end

    if state.sprites.child1 then
        -- Child rotates opposite direction
        state.sprites.child1:set_rotation(-time * 30)
    end

    -- Phase 5: Animate particles
    --if state.particles then
    --    for i, particle in ipairs(state.particles) do
    --        -- Make particles bob up and down with different phases
    --        local x, y = particle:get_position()
    --        local bob_y = y + math.sin(time * 2 + i * 0.5) * 3
    --        particle:set_position(x, bob_y)
--
    --        -- Fade in and out
    --        local particle_opacity = 80 + math.sin(time * 1.5 + i * 0.3) * 40
    --        particle:set_opacity(particle_opacity)
    --    end
    --end

    -- Demo phase transitions
    if time > 30 and state.demo_phase == 1 then
        print("Player " .. player_id .. ": Transitioning to phase 2")
        state.demo_phase = 2

        -- Show batch update feature
        SpriteSystem.batch_update(player_id, {
            demo_sprite1 = { r = 255, g = 100, b = 100, opacity = 200 },
            demo_sprite2 = { sx = 1.8, sy = 1.8, ro = 45 },
            demo_sprite3 = { anim_state = "IDLE_D", color_mode = SpriteSystem.COLOR_MODE.ADDITIVE }
        })

        -- Group operation: hide some sprites temporarily
        local sprites_to_hide = { "demo_sprite1", "demo_sprite2", "demo_sprite3" }
        SpriteSystem.group_operation(player_id, sprites_to_hide, "set_opacity", 50)

        -- Then show them after delay using timer
        add_timer(state, 2.0, function()
            SpriteSystem.group_operation(player_id, sprites_to_hide, "set_opacity", 200)
        end)
    elseif time > 60 and state.demo_phase == 2 then
        print("Player " .. player_id .. ": Transitioning to phase 3")
        state.demo_phase = 3

        -- Demonstrate z-order reordering
        SpriteSystem.reorder_sprites(player_id, {
            demo_sprite1 = 10,
            demo_sprite2 = 5,
            demo_sprite3 = 15,
            parent_sprite = 20
        })

        -- Cache and restore properties
        if state.sprites.sprite1 then
            state.sprites.sprite1:cache_properties("original", {
                x = 20,
                y = 20,
                opacity = 200,
                r = 255,
                g = 200,
                b = 200
            })

            -- Animate away from cached position
            state.sprites.sprite1:set_position(50, 50)
            state.sprites.sprite1:set_color(100, 100, 255)
            state.sprites.sprite1:set_opacity(100)

            -- Restore after delay using timer
            add_timer(state, 3.0, function()
                if state and state.sprites.sprite1 then
                    state.sprites.sprite1:restore_properties("original")
                end
            end)
        end
    end
end

-- Clean up player sprites
local function cleanup_player_sprites(player_id)
    print("Cleaning up sprites for player: " .. player_id)
    SpriteSystem.cleanup(player_id)
    player_states[player_id] = {}
end

-- Event handlers
Net:on("player_join", function(event)
    local player_id = event.player_id
    print("Player joined: " .. player_id)

    -- Initialize sprites for this player
    init_player_sprites(player_id)
end)

Net:on("player_disconnect", function(event)
    local player_id = event.player_id
    print("Player left: " .. player_id)

    -- Clean up sprites for this player
    cleanup_player_sprites(player_id)
end)

Net:on("tick", function(event)
    local dt = event.delta_time

    -- Update sprites for all players
    for player_id, state in pairs(player_states) do
        update_player_sprites(player_id, dt)
        update_timers(state, dt)
    end
end)

-- Utility function to reset demo for a specific player
local function reset_demo(player_id)
    if player_states[player_id] then
        cleanup_player_sprites(player_id)
        init_player_sprites(player_id)
        print("Demo reset for player: " .. player_id)
        return true
    end
    return false
end
