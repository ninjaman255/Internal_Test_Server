-- sprite_widget/main.lua
local SpriteSystem = {}

-- Internal cache for sprite resources and instances
local _sprite_cache = {}      -- player_id -> {sprite_id -> true}
local _instance_registry = {} -- player_id -> {obj_id -> SpriteObject}
local _layout_registry = {}   -- player_id -> {obj_id -> LayoutObject}

-- Color mode constants
local COLOR_MODE = {
    MULTIPLY = 0,
    ADDITIVE = 1,
    COLORIZE = 2
}

-- Transform function for coordinate system
local function transform_coordinate(value)
    return (value or 0) * 2
end

local function untransform_coordinate(value)
    return (value or 0) / 2
end

-- Alignment helper functions
local function parse_alignment(alignment)
    local vertical, horizontal = "top", "left"

    if alignment then
        local parts = {}
        for part in alignment:gmatch("[^%-]+") do
            table.insert(parts, part:lower())
        end

        if #parts >= 2 then
            vertical = parts[1]
            horizontal = parts[2]
        elseif #parts == 1 then
            vertical = "center"
            horizontal = "center"
        end
    end

    return vertical, horizontal
end

-- Layout class for positioning and managing child sprites
local Layout = {}
Layout.__index = Layout

function Layout.new(options)
    local self = setmetatable({}, Layout)
    self.type = options.type or "absolute"
    self.x = options.x or 0
    self.y = options.y or 0
    self.z = options.z or 0
    self.spacing = options.spacing or { x = 0, y = 0 }
    self.max_children = options.max_children or math.huge
    self.alignment = options.alignment or "top-left"
    self.children = {}
    self.parent = nil
    self._dirty = false
    self._id = options.id or tostring(math.random(100000, 999999))

    if options.player_id then
        if not _layout_registry[options.player_id] then
            _layout_registry[options.player_id] = {}
        end
        _layout_registry[options.player_id][self._id] = self
    end

    return self
end

function Layout:add_child(sprite_obj)
    if #self.children >= self.max_children then
        return false
    end

    table.insert(self.children, sprite_obj)
    sprite_obj.layout_parent = self
    self._dirty = true
    self:_update_children()
    return true
end

function Layout:add_child_at(sprite_obj, index)
    if #self.children >= self.max_children then
        return false
    end

    index = math.min(math.max(1, index), #self.children + 1)
    table.insert(self.children, index, sprite_obj)
    sprite_obj.layout_parent = self
    self._dirty = true
    self:_update_children()
    return true
end

function Layout:remove_child(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            table.remove(self.children, i)
            sprite_obj.layout_parent = nil
            self._dirty = true
            return true
        end
    end
    return false
end

function Layout:remove_child_at(index)
    if index >= 1 and index <= #self.children then
        local child = self.children[index]
        child.layout_parent = nil
        table.remove(self.children, index)
        self._dirty = true
        return child
    end
    return nil
end

function Layout:clear()
    for _, child in ipairs(self.children) do
        child.layout_parent = nil
    end
    self.children = {}
    self._dirty = true
end

function Layout:set_position(x, y)
    self.x = x
    self.y = y
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_alignment(alignment)
    self.alignment = alignment
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:set_spacing(x, y)
    self.spacing.x = x or self.spacing.x
    self.spacing.y = y or self.spacing.y
    self._dirty = true
    self:_update_children()
    return self
end

function Layout:swap_children(index1, index2)
    if index1 >= 1 and index1 <= #self.children and
        index2 >= 1 and index2 <= #self.children then
        self.children[index1], self.children[index2] =
            self.children[index2], self.children[index1]
        self._dirty = true
        self:_update_children()
        return true
    end
    return false
end

function Layout:move_child(from_index, to_index)
    if from_index >= 1 and from_index <= #self.children and
        to_index >= 1 and to_index <= #self.children then
        local child = table.remove(self.children, from_index)
        table.insert(self.children, to_index, child)
        self._dirty = true
        self:_update_children()
        return true
    end
    return false
end

function Layout:get_child_count()
    return #self.children
end

function Layout:get_child_at(index)
    return self.children[index]
end

function Layout:get_child_index(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            return i
        end
    end
    return -1
end

function Layout:bring_child_to_front(sprite_obj)
    local index = self:get_child_index(sprite_obj)
    if index > 0 then
        return self:move_child(index, #self.children)
    end
    return false
end

function Layout:send_child_to_back(sprite_obj)
    local index = self:get_child_index(sprite_obj)
    if index > 0 then
        return self:move_child(index, 1)
    end
    return false
end

function Layout:_calculate_alignment_offset(total_width, total_height, vertical, horizontal)
    local offset_x, offset_y = 0, 0

    if horizontal == "center" then
        offset_x = -total_width / 2
    elseif horizontal == "right" then
        offset_x = -total_width
    end

    if vertical == "center" then
        offset_y = -total_height / 2
    elseif vertical == "bottom" then
        offset_y = -total_height
    end

    return offset_x, offset_y
end

function Layout:_update_children()
    if not self._dirty then return end

    local transformed_x = transform_coordinate(self.x)
    local transformed_y = transform_coordinate(self.y)
    local transformed_spacing_x = transform_coordinate(self.spacing.x)
    local transformed_spacing_y = transform_coordinate(self.spacing.y)

    local vertical, horizontal = parse_alignment(self.alignment)

    if self.type == "horizontal" then
        local total_width = 0
        for _, child in ipairs(self.children) do
            local child_scaled_width = child:get_scaled_width() or 64
            total_width = total_width + child_scaled_width + transformed_spacing_x
        end
        if #self.children > 0 then
            total_width = total_width - transformed_spacing_x
        end

        local align_offset_x, align_offset_y = self:_calculate_alignment_offset(
            total_width, 0, vertical, horizontal
        )

        local current_x = transformed_x + align_offset_x
        for _, child in ipairs(self.children) do
            local child_scaled_width = child:get_scaled_width() or 64
            local child_scaled_height = child:get_scaled_height() or 64

            local child_y = transformed_y + align_offset_y
            if vertical == "center" then
                child_y = child_y + (child_scaled_height / 2)
            elseif vertical == "bottom" then
                child_y = child_y + child_scaled_height
            end

            child:set_raw_position(current_x, child_y)
            current_x = current_x + child_scaled_width + transformed_spacing_x
        end
    elseif self.type == "vertical" then
        local total_height = 0
        for _, child in ipairs(self.children) do
            local child_scaled_height = child:get_scaled_height() or 64
            total_height = total_height + child_scaled_height + transformed_spacing_y
        end
        if #self.children > 0 then
            total_height = total_height - transformed_spacing_y
        end

        local align_offset_x, align_offset_y = self:_calculate_alignment_offset(
            0, total_height, vertical, horizontal
        )

        local current_y = transformed_y + align_offset_y
        for _, child in ipairs(self.children) do
            local child_scaled_width = child:get_scaled_width() or 64
            local child_scaled_height = child:get_scaled_height() or 64

            local child_x = transformed_x + align_offset_x
            if horizontal == "center" then
                child_x = child_x + (child_scaled_width / 2)
            elseif horizontal == "right" then
                child_x = child_x + child_scaled_width
            end

            child:set_raw_position(child_x, current_y)
            current_y = current_y + child_scaled_height + transformed_spacing_y
        end
    elseif self.type == "grid" then
        if #self.children == 0 then return end

        -- Calculate appropriate column count (square grid)
        local grid_cols = math.ceil(math.sqrt(#self.children))
        if grid_cols == 0 then grid_cols = 1 end
        
        local grid_rows = math.ceil(#self.children / grid_cols)
        
        -- Calculate maximum child dimensions
        local max_child_width = 0
        local max_child_height = 0
        for _, child in ipairs(self.children) do
            local child_width = child:get_scaled_width() or 64
            local child_height = child:get_scaled_height() or 64
            max_child_width = math.max(max_child_width, child_width)
            max_child_height = math.max(max_child_height, child_height)
        end
        
        -- Calculate total grid dimensions
        local total_width = (max_child_width * grid_cols) + (transformed_spacing_x * (grid_cols - 1))
        local total_height = (max_child_height * grid_rows) + (transformed_spacing_y * (grid_rows - 1))
        
        local align_offset_x, align_offset_y = self:_calculate_alignment_offset(
            total_width, total_height, vertical, horizontal
        )

        -- Position each child in the grid
        for i, child in ipairs(self.children) do
            local row = math.floor((i - 1) / grid_cols)
            local col = (i - 1) % grid_cols
            
            local x = transformed_x + align_offset_x + 
                     (col * (max_child_width + transformed_spacing_x))
            local y = transformed_y + align_offset_y + 
                     (row * (max_child_height + transformed_spacing_y))
            
            child:set_raw_position(x, y)
        end
    elseif self.type == "relative" then
        for _, child in ipairs(self.children) do
            child:set_raw_position(
                transformed_x + (child._obj.offset_x or 0),
                transformed_y + (child._obj.offset_y or 0)
            )
        end
    elseif self.type == "absolute" then
        for _, child in ipairs(self.children) do
            child:set_raw_position(transformed_x, transformed_y)
        end
    end

    self._dirty = false
end

-- Sprite Object class
local SpriteObject = {}
SpriteObject.__index = SpriteObject

function SpriteObject.new(player_id, sprite_id, width, height, obj_id, options)
    local self = setmetatable({}, SpriteObject)

    self._player_id = player_id
    self._sprite_id = sprite_id
    self._obj_id = obj_id

    -- Store base dimensions (without scale)
    self._base_width = transform_coordinate(width or 64)
    self._base_height = transform_coordinate(height or 64)

    local transformed_x = transform_coordinate(options.x)
    local transformed_y = transform_coordinate(options.y)
    local transformed_sx = options.sx or 2.0
    local transformed_sy = options.sy or 2.0

    self._obj = {
        id = obj_id,
        x = transformed_x,
        y = transformed_y,
        z = options.z or 0,
        sx = transformed_sx,
        sy = transformed_sy,
        ro = options.ro or 0,
        opacity = options.opacity or 255,
        r = options.r or 255,
        g = options.g or 255,
        b = options.b or 255,
        a = options.a or 255,
        color_mode = options.color_mode or 0,
        anim_state = options.anim_state,
        ox = options.ox or 0,
        oy = options.oy or 0,
    }

    self.layout_parent = nil
    self.children = {}
    self._cached_properties = {}

    return self
end

-- Get scaled dimensions (base dimensions * scale)
function SpriteObject:get_scaled_width()
    return self._base_width * (self._obj.sx or 1)
end

function SpriteObject:get_scaled_height()
    return self._base_height * (self._obj.sy or 1)
end

-- Get base dimensions (without scale)
function SpriteObject:get_base_width()
    return untransform_coordinate(self._base_width)
end

function SpriteObject:get_base_height()
    return untransform_coordinate(self._base_height)
end

-- Set base dimensions (affects scale calculations)
function SpriteObject:set_base_width(width)
    self._base_width = transform_coordinate(width)
    -- Mark layout as dirty if parent exists
    if self.layout_parent then
        self.layout_parent._dirty = true
    end
    return self
end

function SpriteObject:set_base_height(height)
    self._base_height = transform_coordinate(height)
    if self.layout_parent then
        self.layout_parent._dirty = true
    end
    return self
end

function SpriteObject:set_base_size(width, height)
    self:set_base_width(width)
    self:set_base_height(height)
    return self
end

function SpriteObject:draw()
    print("SEND TO NET - Player: " .. self._player_id .. 
          ", Sprite: " .. self._sprite_id ..
          ", Obj ID: " .. self._obj_id ..
          ", X: " .. self._obj.x ..
          ", Y: " .. self._obj.y ..
          ", Width: " .. self._base_width ..
          ", Height: " .. self._base_height ..
          ", SX: " .. self._obj.sx ..
          ", SY: " .. self._obj.sy)
    Net.player_draw_sprite(self._player_id, self._sprite_id, self._obj)
    return self
end

function SpriteObject:set_position(x, y)
    local transformed_x = transform_coordinate(x)
    local transformed_y = transform_coordinate(y)
    self._obj.x = transformed_x
    self._obj.y = transformed_y
    self:_update_children_position()

    if self.layout_parent then
        self.layout_parent._dirty = true
    end

    return self
end

function SpriteObject:set_raw_position(x, y)
    self._obj.x = x
    self._obj.y = y
    self:_update_children_position()

    if self.layout_parent then
        self.layout_parent._dirty = true
    end

    return self
end

function SpriteObject:get_position()
    return untransform_coordinate(self._obj.x), untransform_coordinate(self._obj.y)
end

function SpriteObject:get_raw_position()
    return self._obj.x, self._obj.y
end

function SpriteObject:set_scale(sx, sy)
    if sx then self._obj.sx = sx end
    if sy then self._obj.sy = sy end

    -- Scale change affects layout calculations
    if self.layout_parent then
        self.layout_parent._dirty = true
    end

    -- Update children positions (scale affects their relative positions)
    self:_update_children_position()

    self:draw()
    return self
end

function SpriteObject:set_scale_x(sx)
    return self:set_scale(sx, nil)
end

function SpriteObject:set_scale_y(sy)
    return self:set_scale(nil, sy)
end

function SpriteObject:get_scale()
    return self._obj.sx, self._obj.sy
end

function SpriteObject:set_rotation(degrees)
    self._obj.ro = degrees
    self:draw()
    return self
end

function SpriteObject:set_opacity(alpha)
    self._obj.opacity = alpha
    self:draw()
    return self
end

function SpriteObject:set_color(r, g, b, a)
    self._obj.r = r or self._obj.r
    self._obj.g = g or self._obj.g
    self._obj.b = b or self._obj.b
    self._obj.a = a or self._obj.a
    self:draw()
    return self
end

function SpriteObject:set_color_mode(mode)
    self._obj.color_mode = mode
    self:draw()
    return self
end

function SpriteObject:set_animation(state)
    self._obj.anim_state = state
    self:draw()
    return self
end

function SpriteObject:set_visible(visible)
    if visible then
        self:set_opacity(255)
    else
        self:set_opacity(0)
    end
    return self
end

function SpriteObject:add_child(sprite_obj)
    if not sprite_obj or not sprite_obj._obj_id then return self end

    table.insert(self.children, sprite_obj)
    local parent_x, parent_y = self:get_raw_position()
    local child_x, child_y = sprite_obj:get_raw_position()

    sprite_obj._obj.offset_x = (child_x - parent_x)
    sprite_obj._obj.offset_y = (child_y - parent_y)
    return self
end

function SpriteObject:add_child_at(sprite_obj, index)
    if not sprite_obj or not sprite_obj._obj_id then return self end

    index = math.min(math.max(1, index), #self.children + 1)
    table.insert(self.children, index, sprite_obj)
    local parent_x, parent_y = self:get_raw_position()
    local child_x, child_y = sprite_obj:get_raw_position()

    sprite_obj._obj.offset_x = (child_x - parent_x)
    sprite_obj._obj.offset_y = (child_y - parent_y)
    return self
end

function SpriteObject:remove_child(sprite_obj)
    for i, child in ipairs(self.children) do
        if child == sprite_obj then
            table.remove(self.children, i)
            return self
        end
    end
    return self
end

function SpriteObject:remove_child_at(index)
    if index >= 1 and index <= #self.children then
        return table.remove(self.children, index)
    end
    return nil
end

function SpriteObject:swap_children(index1, index2)
    if index1 >= 1 and index1 <= #self.children and
        index2 >= 1 and index2 <= #self.children then
        self.children[index1], self.children[index2] =
            self.children[index2], self.children[index1]
        self:_update_children_position()
        return true
    end
    return false
end

function SpriteObject:move_child(from_index, to_index)
    if from_index >= 1 and from_index <= #self.children and
        to_index >= 1 and to_index <= #self.children then
        local child = table.remove(self.children, from_index)
        table.insert(self.children, to_index, child)
        self:_update_children_position()
        return true
    end
    return false
end

function SpriteObject:bring_child_to_front(child)
    for i, c in ipairs(self.children) do
        if c == child then
            return self:move_child(i, #self.children)
        end
    end
    return false
end

function SpriteObject:send_child_to_back(child)
    for i, c in ipairs(self.children) do
        if c == child then
            return self:move_child(i, 1)
        end
    end
    return false
end

function SpriteObject:get_child_count()
    return #self.children
end

function SpriteObject:get_child_at(index)
    return self.children[index]
end

function SpriteObject:get_child_index(child)
    for i, c in ipairs(self.children) do
        if c == child then
            return i
        end
    end
    return -1
end

function SpriteObject:_update_children_position()
    local parent_x, parent_y = self:get_raw_position()
    for _, child in ipairs(self.children) do
        if child._obj.offset_x and child._obj.offset_y then
            child:set_raw_position(
                parent_x + child._obj.offset_x,
                parent_y + child._obj.offset_y
            )
        end
    end
end

function SpriteObject:cache_properties(key, properties)
    self._cached_properties[key] = properties
    return self
end

function SpriteObject:restore_properties(key)
    local props = self._cached_properties[key]
    if props then
        for k, v in pairs(props) do
            self._obj[k] = v
        end
        self:draw()
    end
    return self
end

function SpriteObject:remove()
    Net.player_erase_sprite(self._player_id, self._obj_id)

    if self.layout_parent then
        self.layout_parent:remove_child(self)
    end

    for _, child in ipairs(self.children) do
        child:remove()
    end
    self.children = {}

    if _instance_registry[self._player_id] then
        _instance_registry[self._player_id][self._obj_id] = nil
    end

    return nil
end

-- Main SpriteSystem API
function SpriteSystem.allocate(player_id, sprite_id, texture_path, anim_path, anim_state)
    if not _sprite_cache[player_id] then
        _sprite_cache[player_id] = {}
    end

    if _sprite_cache[player_id][sprite_id] then
        return true
    end

    local fields = {
        texture_path = texture_path
    }

    if anim_path then
        fields.anim_path = anim_path or ""
        fields.anim_state = anim_state or ""
    end

    Net.player_alloc_sprite(player_id, sprite_id, fields)
    Net.provide_asset_for_player(player_id, texture_path)
    if anim_path ~= nil then
        Net.provide_asset_for_player(player_id, anim_path)
    end
    
    _sprite_cache[player_id][sprite_id] = true

    return true
end

function SpriteSystem.create(player_id, sprite_id, obj_id, options)
    options = options or {}

    if not _sprite_cache[player_id] or not _sprite_cache[player_id][sprite_id] then
        error("Sprite '" .. sprite_id .. "' not allocated for player " .. player_id)
    end

    if not _instance_registry[player_id] then
        _instance_registry[player_id] = {}
    end

    local width = options.width or 64
    local height = options.height or 64
    local sprite_obj = SpriteObject.new(player_id, sprite_id, width, height, obj_id, options)
    _instance_registry[player_id][obj_id] = sprite_obj

    sprite_obj:draw()

    return sprite_obj
end

function SpriteSystem.get_instance(player_id, obj_id)
    if _instance_registry[player_id] then
        return _instance_registry[player_id][obj_id]
    end
    return nil
end

function SpriteSystem.get_all_instances(player_id)
    return _instance_registry[player_id] or {}
end

function SpriteSystem.create_layout(options)
    return Layout.new(options or {})
end

function SpriteSystem.get_layout(player_id, layout_id)
    if _layout_registry[player_id] then
        return _layout_registry[player_id][layout_id]
    end
    return nil
end

function SpriteSystem.get_all_layouts(player_id)
    return _layout_registry[player_id] or {}
end

function SpriteSystem.remove_layout(player_id, layout_id)
    if _layout_registry[player_id] then
        local layout = _layout_registry[player_id][layout_id]
        if layout then
            layout:clear()
            _layout_registry[player_id][layout_id] = nil
            return true
        end
    end
    return false
end

function SpriteSystem.batch_update(player_id, update_table)
    for obj_id, changes in pairs(update_table) do
        local instance = SpriteSystem.get_instance(player_id, obj_id)
        if instance then
            for prop, value in pairs(changes) do
                if prop == "x" or prop == "y" then
                    instance:set_position(changes.x or instance._obj.x, changes.y or instance._obj.y)
                elseif prop == "sx" or prop == "sy" then
                    instance:set_scale(changes.sx, changes.sy)
                elseif prop == "opacity" then
                    instance:set_opacity(value)
                elseif prop == "anim_state" then
                    instance:set_animation(value)
                elseif prop == "width" then
                    instance:set_base_width(value)
                elseif prop == "height" then
                    instance:set_base_height(value)
                end
            end
            instance:draw()
        end
    end
end

function SpriteSystem.group_operation(player_id, obj_ids, operation, ...)
    local results = {}
    for _, obj_id in ipairs(obj_ids) do
        local instance = SpriteSystem.get_instance(player_id, obj_id)
        if instance then
            if operation == "remove" then
                instance:remove()
            elseif operation == "hide" then
                instance:set_visible(false)
            elseif operation == "show" then
                instance:set_visible(true)
            elseif operation == "set_position" then
                local x, y = ...
                instance:set_position(x, y)
            elseif operation == "set_opacity" then
                instance:set_opacity(...)
            elseif operation == "set_scale" then
                local sx, sy = ...
                instance:set_scale(sx, sy)
            elseif operation == "bring_to_front" then
                local layout = instance.layout_parent
                if layout then
                    layout:bring_child_to_front(instance)
                end
            elseif operation == "send_to_back" then
                local layout = instance.layout_parent
                if layout then
                    layout:send_child_to_back(instance)
                end
            end
            table.insert(results, instance)
        end
    end
    return results
end

function SpriteSystem.reorder_sprites(player_id, z_order_table)
    for obj_id, z_index in pairs(z_order_table) do
        local instance = SpriteSystem.get_instance(player_id, obj_id)
        if instance then
            instance._obj.z = z_index
            instance:draw()
        end
    end
end

function SpriteSystem.remove(player_id, obj_id)
    local instance = SpriteSystem.get_instance(player_id, obj_id)
    if instance then
        return instance:remove()
    end
    return nil
end

function SpriteSystem.remove_all(player_id)
    if not _instance_registry[player_id] then return 0 end

    local count = 0
    for obj_id, _ in pairs(_instance_registry[player_id]) do
        SpriteSystem.remove(player_id, obj_id)
        count = count + 1
    end

    return count
end

function SpriteSystem.deallocate(player_id, sprite_id)
    if _sprite_cache[player_id] then
        _sprite_cache[player_id][sprite_id] = nil
    end

    if _instance_registry[player_id] then
        local to_remove = {}
        for obj_id, instance in pairs(_instance_registry[player_id]) do
            if instance._sprite_id == sprite_id then
                table.insert(to_remove, obj_id)
            end
        end

        for _, obj_id in ipairs(to_remove) do
            _instance_registry[player_id][obj_id] = nil
        end
    end

    Net.player_dealloc_sprite(player_id, sprite_id)
    return true
end

function SpriteSystem.cleanup(player_id)
    SpriteSystem.remove_all(player_id)

    if _sprite_cache[player_id] then
        for sprite_id, _ in pairs(_sprite_cache[player_id]) do
            Net.player_dealloc_sprite(player_id, sprite_id)
        end
        _sprite_cache[player_id] = nil
    end

    _instance_registry[player_id] = nil
    _layout_registry[player_id] = nil

    return true
end

-- Utility functions
function SpriteSystem.create_particle_effect(player_id, sprite_id, count, area, options)
    local particles = {}
    options = options or {}

    for i = 1, count do
        local obj_id = options.prefix or ("particle_" .. i)
        local x = math.random(area.x1 or 0, area.x2 or 800)
        local y = math.random(area.y1 or 0, area.y2 or 600)

        local particle = SpriteSystem.create(player_id, sprite_id, obj_id, {
            x = x,
            y = y,
            sx = options.sx or 1,
            sy = options.sy or 1,
            opacity = options.opacity or math.random(100, 255),
            r = options.r,
            g = options.g,
            b = options.b,
            a = options.a,
            anim_state = options.anim_state
        })

        table.insert(particles, particle)
    end

    return particles
end

function SpriteSystem.create_sprite_group(player_id, sprite_id, positions, options)
    local group = {}
    options = options or {}

    for i, pos in ipairs(positions) do
        local obj_id = options.prefix or ("sprite_" .. i)
        local sprite = SpriteSystem.create(player_id, sprite_id, obj_id, {
            x = pos.x,
            y = pos.y,
            z = pos.z or options.z or 0,
            sx = pos.sx or options.sx or 1,
            sy = pos.sy or options.sy or 1,
            opacity = pos.opacity or options.opacity or 255,
            a = pos.a or options.a or 255,
            anim_state = pos.anim_state or options.anim_state,
            width = pos.width or options.width or 64,
            height = pos.height or options.height or 64
        })

        table.insert(group, sprite)
    end

    return group
end

function SpriteSystem.debug_layout(player_id, layout_id)
    local layout = SpriteSystem.get_layout(player_id, layout_id)
    if not layout then
        print("Layout not found:", layout_id)
        return
    end
    
    print("Layout:", layout_id, "Type:", layout.type)
    print("Position:", layout.x, layout.y)
    print("Spacing:", layout.spacing.x, layout.spacing.y)
    print("Children:", #layout.children)
    
    for i, child in ipairs(layout.children) do
        local x, y = child:get_position()
        local width, height = child:get_scaled_width(), child:get_scaled_height()
        print("  Child", i, "at:", x, y, "size:", width, height)
    end
end

-- Expose constants
SpriteSystem.COLOR_MODE = COLOR_MODE

-- Helper functions for coordinate conversion
SpriteSystem.transform_coordinate = transform_coordinate
SpriteSystem.untransform_coordinate = untransform_coordinate

-- Alignment constants for convenience
SpriteSystem.ALIGNMENT = {
    TOP_LEFT = "top-left",
    TOP_CENTER = "top-center",
    TOP_RIGHT = "top-right",
    CENTER_LEFT = "center-left",
    CENTER = "center-center",
    CENTER_RIGHT = "center-right",
    BOTTOM_LEFT = "bottom-left",
    BOTTOM_CENTER = "bottom-center",
    BOTTOM_RIGHT = "bottom-right"
}

return SpriteSystem
