local logger = require('scripts/ezlibs-scripts/ezlogger').get('ezlibs-main')
local startup_start = os.clock()

local helpers = require('scripts/ezlibs-scripts/helpers')
local ezbus = require('scripts/ezlibs-scripts/ezbus')   -- central event bus
local eztriggers = require('scripts/ezlibs-scripts/eztriggers/eztriggers')
local ezcache = require('scripts/ezlibs-scripts/ezcache')
local ezencounters = require('scripts/ezlibs-scripts/ezencounters/main')
local ezbattle_results = require('scripts/ezlibs-scripts/ezbattle_results')
eznpcs = require('scripts/ezlibs-scripts/eznpcs/eznpcs')
local ezmemory = require('scripts/ezlibs-scripts/ezmemory')
local ezmystery = require('scripts/ezlibs-scripts/ezmystery')
local ezweather = require('scripts/ezlibs-scripts/ezweather')
local ezwarps = require('scripts/ezlibs-scripts/ezwarps/main')
local ezfarms = require('scripts/ezlibs-scripts/ezfarms')
helpers.safe_require('scripts/events/eznpcs_onceitem')
local ezcheckpoints = require('scripts/ezlibs-scripts/ezcheckpoints')
local ezannouncement = require('scripts/ezlibs-scripts/ezannounce/ezannounce')
local ezemail = require('scripts/ezlibs-scripts/ezemail')
local ezexplosions = require('scripts/ezlibs-scripts/ezexplosions')
local ezrushroads = require('scripts/ezlibs-scripts/ezrushroads')
local ezpress = require('scripts/ezlibs-scripts/ezpress')
local ezusers = require('scripts/ezlibs-scripts/ezusers')
local ezbbs = require('scripts/ezlibs-scripts/ezbbs')
local ezbuttons = require('scripts/ezlibs-scripts/ezbuttons')
local ezpushback = require('scripts/ezlibs-scripts/eznpcs/ezpushback')
local ezbottriggers = require('scripts/ezlibs-scripts/eztriggers/ezbottriggers')
local ezcutscenes = require('scripts/ezlibs-scripts/ezcutscenes/ezcutscenes')

local plugins = { 
    ezweather, 
    eznpcs, 
    ezmemory, 
    ezmystery, 
    ezwarps, 
    ezencounters,
    eztriggers, 
    ezemail, 
    ezannouncement, 
    ezcheckpoints, 
    ezrushroads,
    ezpress,
    ezusers,
    ezbbs,
    ezbuttons,
    ezpushback,
    ezbottriggers,
    ezcutscenes
}

local sfx = {
    hurt = '/server/assets/ezlibs-assets/sfx/hurt.ogg',
    item_get = '/server/assets/ezlibs-assets/sfx/item_get.ogg',
    recover = '/server/assets/ezlibs-assets/sfx/recover.ogg',
    card_error = '/server/assets/ezlibs-assets/ezfarms/card_error.ogg',
    compressSfx = "/server/assets/ezlibs-assets/sfx/compress.ogg"
}

local custom_script_path = 'scripts/ezlibs-custom/custom'
local custom_plugin = helpers.safe_require(custom_script_path)
if custom_plugin then
    plugins[#plugins + 1] = custom_plugin
end

-- Now that all plugins have been required and registered their handlers,
-- trigger the object registry to preload and cache all objects.
local object_registry = require('scripts/ezlibs-scripts/object_registry')
object_registry.load_all()

eznpcs.load_npcs()
ezrushroads.init()  -- group roads after all objects are cached

Net:on("battle_results", function(event)
    -- Keep the full payload available until this player exits the battle.
    -- Some fields (for example reason) are intentionally not part of the
    -- normalized stats table passed to existing plugins.
    ezbattle_results.store(event.player_id, event)

    local stats = {
        reason=event.reason,
        health=event.health,
        time=event.time,
        ran=event.ran,
        emotion=event.emotion,
        turns=event.turns,
        enemies=event.enemies,
        score=event.score
    }
    for i, plugin in ipairs(plugins) do
        if plugin.handle_battle_results then
            plugin.handle_battle_results(event.player_id, stats)
        end
    end
end)

Net:on("battle_exit", function(event)
    local player_id = event.player_id
    local battle_results = ezbattle_results.peek(player_id)

    for i, plugin in ipairs(plugins) do
        if plugin.handle_battle_exit then
            plugin.handle_battle_exit(player_id, battle_results, event)
        end
    end

    -- Results remain available to every plugin during the fan-out, then are
    -- consumed so a later battle_exit cannot accidentally reuse stale results.
    ezbattle_results.consume(player_id)
end)

Net:on("shop_purchase", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_shop_purchase then
            plugin.handle_shop_purchase(event.player_id, event.item_name)
        end
    end
end)

Net:on("shop_close", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_shop_close then
            plugin.handle_shop_close(event.player_id)
        end
    end
end)

Net:on("custom_warp", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_custom_warp then
            plugin.handle_custom_warp(event.player_id, event.object_id)
        end
    end
end)

Net:on("player_move", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_player_move then
            plugin.handle_player_move(event.player_id, event.x, event.y, event.z)
        end
    end
end)

Net:on("player_request", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_player_request then
            plugin.handle_player_request(event.player_id, event.data)
        end
    end
end)

--Pass handlers on to all the libraries we are using
Net:on("tile_interaction", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_tile_interaction then
            plugin.handle_tile_interaction(event.player_id, event.x, event.y, event.z, event.button)
        end
    end
end)

Net:on("post_selection", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_post_selection then
            plugin.handle_post_selection(event.player_id, event.post_id)
        end
    end
end)

Net:on("board_close", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_board_close then
            plugin.handle_board_close(event.player_id)
        end
    end
end)

Net:on("player_avatar_change", function(event)
    local details = {
        texture_path=event.texture_path,
        animation_path=event.animation_path,
        name=event.name,
        element=event.element,
        max_health=event.max_health,
        prevent_default=event.prevent_default
    }
    for i, plugin in ipairs(plugins) do
        if plugin.handle_player_avatar_change then
            plugin.handle_player_avatar_change(event.player_id, details)
        end
    end
end)

Net:on("player_join", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_player_join then
            plugin.handle_player_join(event.player_id)
        end
    end
    --Provide assets for custom events
    for name, path in pairs(sfx) do
        Net.provide_asset_for_player(event.player_id, path)
    end
end)

Net:on("actor_interaction", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_actor_interaction then
            plugin.handle_actor_interaction(event.player_id, event.actor_id, event.button)
        end
    end
end)

Net:on("tick", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.on_tick then
            plugin.on_tick(event.delta_time)
        end
    end
end)

Net:on("player_disconnect", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_player_disconnect then
            plugin.handle_player_disconnect(event.player_id)
        end
    end
    ezbattle_results.clear(event.player_id)
end)

Net:on("object_interaction", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_object_interaction then
            plugin.handle_object_interaction(event.player_id, event.object_id, event.button)
        end
    end
end)

Net:on("player_area_transfer", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_player_transfer then
            plugin.handle_player_transfer(event.player_id)
        end
    end
end)

Net:on("textbox_response", function(event)
    for i, plugin in ipairs(plugins) do
        if plugin.handle_textbox_response then
            plugin.handle_textbox_response(event.player_id, event.response)
        end
    end
end)

logger:info("[main] ezlibs loaded in " .. (os.clock() - startup_start) .. "s")